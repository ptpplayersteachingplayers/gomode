/**
 * PTP Mobile App - Entry Point
 *
 * Players Teaching Players Soccer Camps
 *
 * Includes:
 * - React Query for data fetching
 * - Authentication context
 * - Navigation
 */

import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import { QueryProvider } from './src/api/QueryProvider';
import { AppNavigator } from './src/navigation';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <QueryProvider>
        <AuthProvider>
          <AppNavigator />
        </AuthProvider>
      </QueryProvider>
    </SafeAreaProvider>
  );
}
