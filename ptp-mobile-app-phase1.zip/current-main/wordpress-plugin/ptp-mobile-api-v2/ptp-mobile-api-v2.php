<?php
/**
 * Plugin Name: PTP Mobile API v2
 * Plugin URI: https://ptpsummercamps.com
 * Description: Enhanced REST API endpoints for the PTP Soccer Camps mobile app - Phase 1+
 * Version: 2.0.0
 * Author: Players Teaching Players
 * Author URI: https://ptpsummercamps.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ptp-mobile-api
 *
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * @package PTP_Mobile_API
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin version
define('PTP_MOBILE_API_VERSION', '2.0.0');

// Plugin directory path
define('PTP_MOBILE_API_PATH', plugin_dir_path(__FILE__));

/**
 * Main PTP Mobile API Class - Enhanced Version
 *
 * Includes:
 * - App configuration endpoint
 * - Enhanced camps with geo-filtering
 * - Promotional banners
 * - Feature flags
 * - Version gating
 */
class PTP_Mobile_API {

    /**
     * REST API namespace
     *
     * @var string
     */
    private $namespace = 'ptp/v1';

    /**
     * Database table name for device tokens
     *
     * @var string
     */
    private $devices_table;

    /**
     * Database table name for promotions
     *
     * @var string
     */
    private $promotions_table;

    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->devices_table = $wpdb->prefix . 'ptp_mobile_devices';
        $this->promotions_table = $wpdb->prefix . 'ptp_promotions';

        // Register REST API routes
        add_action('rest_api_init', array($this, 'register_routes'));

        // Create database tables on activation
        register_activation_hook(__FILE__, array($this, 'activate'));

        // Add CORS headers for mobile app
        add_action('rest_api_init', array($this, 'add_cors_headers'));

        // Add admin menu for managing promotions
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Plugin activation
     */
    public function activate() {
        $this->create_devices_table();
        $this->create_promotions_table();
        $this->set_default_options();
    }

    /**
     * Create devices table using dbDelta
     */
    private function create_devices_table() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$this->devices_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            token VARCHAR(255) NOT NULL,
            platform VARCHAR(20) DEFAULT 'unknown',
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_token (user_id, token),
            KEY user_id (user_id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Create promotions table
     */
    private function create_promotions_table() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$this->promotions_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            body TEXT,
            cta_text VARCHAR(100),
            cta_url VARCHAR(500),
            image_url VARCHAR(500),
            background_color VARCHAR(20) DEFAULT '#2563eb',
            start_date DATETIME,
            end_date DATETIME,
            priority INT(11) DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY is_active (is_active),
            KEY priority (priority)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Set default options for feature flags
     */
    private function set_default_options() {
        $defaults = array(
            'ptp_feature_private_training' => '1',
            'ptp_feature_messaging' => '0',
            'ptp_feature_waitlist' => '1',
            'ptp_feature_push_notifications' => '1',
            'ptp_feature_nearby_camps' => '1',
            'ptp_feature_trainer_reviews' => '0',
            'ptp_min_app_version' => '1.0.0',
            'ptp_latest_app_version' => '1.0.0',
            'ptp_ios_store_url' => 'https://apps.apple.com/app/ptp-soccer-camps/id000000000',
            'ptp_android_store_url' => 'https://play.google.com/store/apps/details?id=com.ptpsummercamps.app',
            'ptp_support_email' => 'info@ptpsummercamps.com',
            'ptp_support_phone' => '',
            'ptp_support_hours' => 'Mon-Fri 9am-5pm EST',
        );

        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }

        update_option('ptp_mobile_api_db_version', PTP_MOBILE_API_VERSION);
    }

    /**
     * Add CORS headers for mobile app requests
     */
    public function add_cors_headers() {
        remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
        add_filter('rest_pre_serve_request', function($value) {
            header('Access-Control-Allow-Origin: *');
            header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
            header('Access-Control-Allow-Headers: Authorization, Content-Type');
            header('Access-Control-Allow-Credentials: true');
            return $value;
        });
    }

    /**
     * Register REST API routes
     */
    public function register_routes() {
        // =================================================================
        // NEW: App Configuration Endpoint
        // =================================================================
        register_rest_route($this->namespace, '/app-config', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array($this, 'get_app_config'),
            'permission_callback' => '__return_true',
        ));

        // =================================================================
        // Existing Endpoints (enhanced)
        // =================================================================

        // GET /ptp/v1/me - Get current user info
        register_rest_route($this->namespace, '/me', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array($this, 'get_me'),
            'permission_callback' => array($this, 'require_login'),
        ));

        // GET /ptp/v1/camps - Enhanced with geo-filtering
        register_rest_route($this->namespace, '/camps', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array($this, 'get_camps'),
            'permission_callback' => '__return_true',
            'args'                => array(
                'lat' => array(
                    'type'              => 'number',
                    'sanitize_callback' => 'floatval',
                ),
                'lng' => array(
                    'type'              => 'number',
                    'sanitize_callback' => 'floatval',
                ),
                'radius' => array(
                    'type'              => 'integer',
                    'default'           => 50,
                    'sanitize_callback' => 'absint',
                ),
                'state' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'category' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));

        // GET /ptp/v1/trainers
        register_rest_route($this->namespace, '/trainers', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array($this, 'get_trainers'),
            'permission_callback' => '__return_true',
        ));

        // GET /ptp/v1/sessions
        register_rest_route($this->namespace, '/sessions', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array($this, 'get_sessions'),
            'permission_callback' => array($this, 'require_login'),
        ));

        // POST /ptp/v1/devices
        register_rest_route($this->namespace, '/devices', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array($this, 'register_device'),
            'permission_callback' => array($this, 'require_login'),
            'args'                => array(
                'token' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'validate_callback' => function($param) {
                        return !empty($param) && strlen($param) <= 255;
                    },
                ),
                'platform' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'validate_callback' => function($param) {
                        return in_array($param, array('ios', 'android'), true);
                    },
                ),
            ),
        ));

        // =================================================================
        // NEW: Home Screen Data Endpoint (combines multiple queries)
        // =================================================================
        register_rest_route($this->namespace, '/home', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array($this, 'get_home_data'),
            'permission_callback' => array($this, 'require_login'),
        ));
    }

    /**
     * Permission callback: Require authenticated user
     *
     * @return bool|WP_Error
     */
    public function require_login() {
        if (!is_user_logged_in()) {
            return new WP_Error(
                'rest_not_logged_in',
                __('You must be logged in to access this endpoint.', 'ptp-mobile-api'),
                array('status' => 401)
            );
        }
        return true;
    }

    // =========================================================================
    // APP CONFIG ENDPOINT
    // =========================================================================

    /**
     * GET /ptp/v1/app-config
     *
     * Returns app configuration including feature flags, promotions, version info
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_app_config($request) {
        $response = array(
            'features' => $this->get_feature_flags(),
            'promotions' => $this->get_active_promotions(),
            'versioning' => array(
                'minSupportedVersion' => get_option('ptp_min_app_version', '1.0.0'),
                'latestVersion' => get_option('ptp_latest_app_version', '1.0.0'),
                'updateUrl' => array(
                    'ios' => get_option('ptp_ios_store_url', ''),
                    'android' => get_option('ptp_android_store_url', ''),
                ),
                'updateMessage' => get_option('ptp_update_message', ''),
            ),
            'markets' => $this->get_markets(),
            'support' => array(
                'email' => get_option('ptp_support_email', 'info@ptpsummercamps.com'),
                'phone' => get_option('ptp_support_phone', ''),
                'hours' => get_option('ptp_support_hours', ''),
            ),
            'updatedAt' => current_time('c'),
        );

        return rest_ensure_response($response);
    }

    /**
     * Get feature flags from options
     */
    private function get_feature_flags() {
        return array(
            'enablePrivateTraining' => get_option('ptp_feature_private_training', '1') === '1',
            'enableMessaging' => get_option('ptp_feature_messaging', '0') === '1',
            'enableWaitlist' => get_option('ptp_feature_waitlist', '1') === '1',
            'enablePushNotifications' => get_option('ptp_feature_push_notifications', '1') === '1',
            'enableNearbyCamps' => get_option('ptp_feature_nearby_camps', '1') === '1',
            'enableTrainerReviews' => get_option('ptp_feature_trainer_reviews', '0') === '1',
        );
    }

    /**
     * Get active promotions from database
     */
    private function get_active_promotions() {
        global $wpdb;

        $now = current_time('mysql');

        $promotions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->promotions_table}
            WHERE is_active = 1
            AND (start_date IS NULL OR start_date <= %s)
            AND (end_date IS NULL OR end_date >= %s)
            ORDER BY priority DESC, created_at DESC
            LIMIT 10",
            $now,
            $now
        ), ARRAY_A);

        if (empty($promotions)) {
            return array();
        }

        return array_map(function($promo) {
            return array(
                'id' => (string) $promo['id'],
                'title' => $promo['title'],
                'body' => $promo['body'],
                'ctaText' => $promo['cta_text'],
                'ctaUrl' => $promo['cta_url'],
                'imageUrl' => $promo['image_url'],
                'backgroundColor' => $promo['background_color'],
                'startDate' => $promo['start_date'],
                'endDate' => $promo['end_date'],
                'priority' => (int) $promo['priority'],
            );
        }, $promotions);
    }

    /**
     * Get available markets
     */
    private function get_markets() {
        return array(
            array('code' => 'PA', 'name' => 'Pennsylvania', 'isActive' => true),
            array('code' => 'NJ', 'name' => 'New Jersey', 'isActive' => true),
            array('code' => 'DE', 'name' => 'Delaware', 'isActive' => true),
            array('code' => 'MD', 'name' => 'Maryland', 'isActive' => true),
            array('code' => 'NY', 'name' => 'New York', 'isActive' => true),
        );
    }

    // =========================================================================
    // USER ENDPOINT
    // =========================================================================

    /**
     * GET /ptp/v1/me
     */
    public function get_me($request) {
        $user = wp_get_current_user();

        if (!$user->exists()) {
            return new WP_Error(
                'rest_user_not_found',
                __('User not found.', 'ptp-mobile-api'),
                array('status' => 404)
            );
        }

        $roles = $user->roles;
        $role = !empty($roles) ? reset($roles) : 'subscriber';

        // Get extended user meta
        $phone = get_user_meta($user->ID, 'billing_phone', true);
        $zip = get_user_meta($user->ID, 'billing_postcode', true);

        $response = array(
            'id'    => $user->ID,
            'name'  => $user->display_name,
            'email' => $user->user_email,
            'role'  => $role,
            'phone' => $phone ?: null,
            'zip'   => $zip ?: null,
        );

        return rest_ensure_response($response);
    }

    // =========================================================================
    // ENHANCED CAMPS ENDPOINT
    // =========================================================================

    /**
     * GET /ptp/v1/camps
     *
     * Enhanced with seat availability, geo-filtering, and timestamps
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function get_camps($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error(
                'woocommerce_not_active',
                __('WooCommerce is required for this endpoint.', 'ptp-mobile-api'),
                array('status' => 500)
            );
        }

        // Get filter params
        $lat = $request->get_param('lat');
        $lng = $request->get_param('lng');
        $radius = $request->get_param('radius') ?: 50;
        $state_filter = $request->get_param('state');
        $category_filter = $request->get_param('category');

        // Build tax query
        $tax_query = array(
            array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => $category_filter ? array($category_filter) : array('summer', 'winter-clinics'),
            ),
        );

        $args = array(
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'orderby'        => 'meta_value',
            'meta_key'       => '_camp_date',
            'order'          => 'ASC',
            'tax_query'      => $tax_query,
        );

        // Add state filter to meta query
        if ($state_filter) {
            $args['meta_query'] = array(
                array(
                    'key'     => '_camp_state',
                    'value'   => $state_filter,
                    'compare' => '=',
                ),
            );
        }

        $products = get_posts($args);
        $camps = array();

        foreach ($products as $product) {
            $wc_product = wc_get_product($product->ID);

            if (!$wc_product) {
                continue;
            }

            // Get product category
            $categories = wp_get_post_terms($product->ID, 'product_cat', array('fields' => 'slugs'));
            $category = !empty($categories) ? $categories[0] : 'summer';

            // Get product image
            $image_id = $wc_product->get_image_id();
            $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium') : null;

            // Get custom meta
            $camp_date = get_post_meta($product->ID, '_camp_date', true);
            $camp_time = get_post_meta($product->ID, '_camp_time', true);
            $camp_location = get_post_meta($product->ID, '_camp_location', true);
            $camp_state = get_post_meta($product->ID, '_camp_state', true);
            $bestseller = get_post_meta($product->ID, '_bestseller', true);
            $almost_full = get_post_meta($product->ID, '_almost_full', true);

            // Enhanced: Get stock info
            $stock_quantity = $wc_product->get_stock_quantity();
            $stock_status = $wc_product->get_stock_status();

            // Calculate seats
            $total_seats = get_post_meta($product->ID, '_camp_total_seats', true) ?: 20;
            $available_seats = $stock_quantity !== null ? $stock_quantity : $total_seats;

            // Check waitlist status
            $is_waitlist = $stock_status === 'onbackorder' || ($stock_quantity !== null && $stock_quantity <= 0);

            // Enhanced: Get coordinates for distance calc
            $camp_lat = get_post_meta($product->ID, '_camp_lat', true);
            $camp_lng = get_post_meta($product->ID, '_camp_lng', true);

            $camp_data = array(
                'id'              => $product->ID,
                'name'            => $wc_product->get_name(),
                'image'           => $image_url,
                'price'           => $wc_product->get_price_html() ? wp_strip_all_tags($wc_product->get_price_html()) : '$' . $wc_product->get_price(),
                'date'            => $camp_date ?: '',
                'time'            => $camp_time ?: '',
                'location'        => $camp_location ?: '',
                'state'           => $camp_state ?: '',
                'bestseller'      => $bestseller === 'yes',
                'almost_full'     => $almost_full === 'yes' || ($available_seats > 0 && $available_seats <= 5),
                'product_url'     => get_permalink($product->ID),
                'description'     => $wc_product->get_short_description(),
                'category'        => $category,
                // Enhanced fields
                'totalSeats'      => (int) $total_seats,
                'availableSeats'  => max(0, (int) $available_seats),
                'isWaitlistOnly'  => $is_waitlist,
                'lastUpdatedAt'   => get_the_modified_date('c', $product->ID),
            );

            // Calculate distance if coordinates provided
            if ($lat && $lng && $camp_lat && $camp_lng) {
                $distance = $this->calculate_distance($lat, $lng, floatval($camp_lat), floatval($camp_lng));
                $camp_data['distance'] = round($distance, 1);
                $camp_data['distanceUnit'] = 'miles';

                // Filter by radius
                if ($distance > $radius) {
                    continue;
                }
            }

            $camps[] = $camp_data;
        }

        // Sort by distance if geo-filtering
        if ($lat && $lng) {
            usort($camps, function($a, $b) {
                $dist_a = $a['distance'] ?? PHP_INT_MAX;
                $dist_b = $b['distance'] ?? PHP_INT_MAX;
                return $dist_a <=> $dist_b;
            });
        }

        return rest_ensure_response($camps);
    }

    /**
     * Calculate distance between two coordinates (Haversine formula)
     *
     * @param float $lat1 Latitude 1
     * @param float $lng1 Longitude 1
     * @param float $lat2 Latitude 2
     * @param float $lng2 Longitude 2
     * @return float Distance in miles
     */
    private function calculate_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 3959; // miles

        $lat1_rad = deg2rad($lat1);
        $lat2_rad = deg2rad($lat2);
        $delta_lat = deg2rad($lat2 - $lat1);
        $delta_lng = deg2rad($lng2 - $lng1);

        $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($delta_lng / 2) * sin($delta_lng / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earth_radius * $c;
    }

    // =========================================================================
    // TRAINERS ENDPOINT
    // =========================================================================

    /**
     * GET /ptp/v1/trainers
     */
    public function get_trainers($request) {
        if (!post_type_exists('ptp_trainer')) {
            return rest_ensure_response(array());
        }

        $args = array(
            'post_type'      => 'ptp_trainer',
            'post_status'    => 'publish',
            'posts_per_page' => 50,
            'orderby'        => 'menu_order title',
            'order'          => 'ASC',
        );

        $trainers_query = get_posts($args);
        $trainers = array();

        foreach ($trainers_query as $trainer_post) {
            $photo_id = get_post_thumbnail_id($trainer_post->ID);
            $photo_url = $photo_id ? wp_get_attachment_image_url($photo_id, 'medium') : null;

            $college = get_post_meta($trainer_post->ID, '_ptp_college', true);
            $bio = get_post_meta($trainer_post->ID, '_ptp_bio', true);
            $city = get_post_meta($trainer_post->ID, '_ptp_city', true);
            $specialty = get_post_meta($trainer_post->ID, '_ptp_specialty', true);
            $rating = get_post_meta($trainer_post->ID, '_ptp_avg_rating', true);

            $trainers[] = array(
                'id'        => $trainer_post->ID,
                'name'      => $trainer_post->post_title,
                'photo'     => $photo_url,
                'college'   => $college ?: '',
                'bio'       => $bio ?: $trainer_post->post_content,
                'city'      => $city ?: '',
                'specialty' => $specialty ?: '',
                'rating'    => $rating ? (float) $rating : 0,
            );
        }

        return rest_ensure_response($trainers);
    }

    // =========================================================================
    // SESSIONS ENDPOINT
    // =========================================================================

    /**
     * GET /ptp/v1/sessions
     */
    public function get_sessions($request) {
        $user_id = get_current_user_id();
        $sessions = array();

        if (class_exists('WooCommerce')) {
            $orders = wc_get_orders(array(
                'customer_id' => $user_id,
                'status'      => array('completed', 'processing', 'on-hold'),
                'limit'       => 50,
                'orderby'     => 'date',
                'order'       => 'DESC',
            ));

            foreach ($orders as $order) {
                foreach ($order->get_items() as $item) {
                    $product_id = $item->get_product_id();
                    $product = wc_get_product($product_id);

                    if (!$product) {
                        continue;
                    }

                    $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'slugs'));
                    $is_camp = array_intersect($categories, array('summer', 'winter-clinics'));

                    if (empty($is_camp)) {
                        continue;
                    }

                    $type = in_array('winter-clinics', $categories, true) ? 'clinic' : 'camp';

                    $camp_date = get_post_meta($product_id, '_camp_date', true);
                    $camp_time = get_post_meta($product_id, '_camp_time', true);
                    $camp_location = get_post_meta($product_id, '_camp_location', true);

                    $status = 'upcoming';
                    if ($camp_date) {
                        $camp_timestamp = strtotime($camp_date);
                        if ($camp_timestamp && $camp_timestamp < time()) {
                            $status = 'completed';
                        }
                    }

                    $sessions[] = array(
                        'id'           => $item->get_id(),
                        'type'         => $type,
                        'name'         => $product->get_name(),
                        'date'         => $camp_date ?: 'TBD',
                        'time'         => $camp_time ?: '',
                        'location'     => $camp_location ?: '',
                        'trainer_name' => null,
                        'status'       => $status,
                    );
                }
            }
        }

        $sessions = apply_filters('ptp_user_sessions', $sessions, $user_id);

        usort($sessions, function($a, $b) {
            $date_a = strtotime($a['date']) ?: PHP_INT_MAX;
            $date_b = strtotime($b['date']) ?: PHP_INT_MAX;
            return $date_a - $date_b;
        });

        return rest_ensure_response($sessions);
    }

    // =========================================================================
    // HOME SCREEN DATA ENDPOINT
    // =========================================================================

    /**
     * GET /ptp/v1/home
     *
     * Combined endpoint for home screen data (reduces API calls)
     */
    public function get_home_data($request) {
        $user = wp_get_current_user();
        $user_id = $user->ID;

        // Get sessions
        $sessions_response = $this->get_sessions($request);
        $sessions = $sessions_response->get_data();

        // Find next session
        $next_session = null;
        foreach ($sessions as $session) {
            if ($session['status'] === 'upcoming') {
                $next_session = $session;
                break;
            }
        }

        // Count stats
        $upcoming_count = count(array_filter($sessions, function($s) {
            return $s['status'] === 'upcoming';
        }));
        $completed_count = count(array_filter($sessions, function($s) {
            return $s['status'] === 'completed';
        }));

        // Get active promotions
        $promotions = $this->get_active_promotions();

        return rest_ensure_response(array(
            'user' => array(
                'id'    => $user->ID,
                'name'  => $user->display_name,
                'email' => $user->user_email,
            ),
            'nextSession' => $next_session,
            'unreadMessages' => 0, // Will be populated in Phase 2
            'promotions' => $promotions,
            'stats' => array(
                'upcomingCamps' => $upcoming_count,
                'completedCamps' => $completed_count,
            ),
        ));
    }

    // =========================================================================
    // DEVICE REGISTRATION
    // =========================================================================

    /**
     * POST /ptp/v1/devices
     */
    public function register_device($request) {
        global $wpdb;

        $user_id = get_current_user_id();
        $token = sanitize_text_field($request->get_param('token'));
        $platform = sanitize_text_field($request->get_param('platform'));

        if (empty($token) || empty($platform)) {
            return new WP_Error(
                'invalid_params',
                __('Token and platform are required.', 'ptp-mobile-api'),
                array('status' => 400)
            );
        }

        $result = $wpdb->replace(
            $this->devices_table,
            array(
                'user_id'    => $user_id,
                'token'      => $token,
                'platform'   => $platform,
                'updated_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s')
        );

        if ($result === false) {
            return new WP_Error(
                'db_error',
                __('Failed to register device.', 'ptp-mobile-api'),
                array('status' => 500)
            );
        }

        $this->cleanup_old_devices($user_id);

        return rest_ensure_response(array(
            'success' => true,
        ));
    }

    /**
     * Remove old device tokens for a user
     */
    private function cleanup_old_devices($user_id) {
        global $wpdb;

        $keep_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$this->devices_table}
            WHERE user_id = %d
            ORDER BY updated_at DESC
            LIMIT 5",
            $user_id
        ));

        if (empty($keep_ids)) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($keep_ids), '%d'));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->devices_table}
            WHERE user_id = %d AND id NOT IN ($placeholders)",
            array_merge(array($user_id), $keep_ids)
        ));
    }

    // =========================================================================
    // ADMIN MENU & SETTINGS
    // =========================================================================

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'PTP Mobile App',
            'PTP Mobile App',
            'manage_options',
            'ptp-mobile-app',
            array($this, 'render_admin_page'),
            'dashicons-smartphone',
            56
        );

        add_submenu_page(
            'ptp-mobile-app',
            'Settings',
            'Settings',
            'manage_options',
            'ptp-mobile-app',
            array($this, 'render_admin_page')
        );

        add_submenu_page(
            'ptp-mobile-app',
            'Promotions',
            'Promotions',
            'manage_options',
            'ptp-mobile-promotions',
            array($this, 'render_promotions_page')
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        // Feature flags
        register_setting('ptp_mobile_settings', 'ptp_feature_private_training');
        register_setting('ptp_mobile_settings', 'ptp_feature_messaging');
        register_setting('ptp_mobile_settings', 'ptp_feature_waitlist');
        register_setting('ptp_mobile_settings', 'ptp_feature_push_notifications');
        register_setting('ptp_mobile_settings', 'ptp_feature_nearby_camps');
        register_setting('ptp_mobile_settings', 'ptp_feature_trainer_reviews');

        // Version settings
        register_setting('ptp_mobile_settings', 'ptp_min_app_version');
        register_setting('ptp_mobile_settings', 'ptp_latest_app_version');
        register_setting('ptp_mobile_settings', 'ptp_ios_store_url');
        register_setting('ptp_mobile_settings', 'ptp_android_store_url');
        register_setting('ptp_mobile_settings', 'ptp_update_message');

        // Support settings
        register_setting('ptp_mobile_settings', 'ptp_support_email');
        register_setting('ptp_mobile_settings', 'ptp_support_phone');
        register_setting('ptp_mobile_settings', 'ptp_support_hours');
    }

    /**
     * Render admin settings page
     */
    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1>PTP Mobile App Settings</h1>

            <form method="post" action="options.php">
                <?php settings_fields('ptp_mobile_settings'); ?>

                <h2>Feature Flags</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Private Training</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptp_feature_private_training" value="1"
                                    <?php checked(get_option('ptp_feature_private_training', '1'), '1'); ?>>
                                Enable private training booking
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Messaging</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptp_feature_messaging" value="1"
                                    <?php checked(get_option('ptp_feature_messaging', '0'), '1'); ?>>
                                Enable in-app messaging (Phase 2)
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Waitlist</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptp_feature_waitlist" value="1"
                                    <?php checked(get_option('ptp_feature_waitlist', '1'), '1'); ?>>
                                Enable camp waitlist
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Push Notifications</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptp_feature_push_notifications" value="1"
                                    <?php checked(get_option('ptp_feature_push_notifications', '1'), '1'); ?>>
                                Enable push notifications
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Nearby Camps</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptp_feature_nearby_camps" value="1"
                                    <?php checked(get_option('ptp_feature_nearby_camps', '1'), '1'); ?>>
                                Enable location-based camp search
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Trainer Reviews</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptp_feature_trainer_reviews" value="1"
                                    <?php checked(get_option('ptp_feature_trainer_reviews', '0'), '1'); ?>>
                                Enable trainer ratings/reviews
                            </label>
                        </td>
                    </tr>
                </table>

                <h2>App Version Settings</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Minimum Supported Version</th>
                        <td>
                            <input type="text" name="ptp_min_app_version"
                                value="<?php echo esc_attr(get_option('ptp_min_app_version', '1.0.0')); ?>"
                                class="regular-text">
                            <p class="description">Users below this version will be forced to update</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Latest Version</th>
                        <td>
                            <input type="text" name="ptp_latest_app_version"
                                value="<?php echo esc_attr(get_option('ptp_latest_app_version', '1.0.0')); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">iOS Store URL</th>
                        <td>
                            <input type="url" name="ptp_ios_store_url"
                                value="<?php echo esc_attr(get_option('ptp_ios_store_url', '')); ?>"
                                class="large-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Android Store URL</th>
                        <td>
                            <input type="url" name="ptp_android_store_url"
                                value="<?php echo esc_attr(get_option('ptp_android_store_url', '')); ?>"
                                class="large-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Update Message</th>
                        <td>
                            <textarea name="ptp_update_message" rows="3" class="large-text"><?php echo esc_textarea(get_option('ptp_update_message', '')); ?></textarea>
                            <p class="description">Optional message shown when prompting update</p>
                        </td>
                    </tr>
                </table>

                <h2>Support Info</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Support Email</th>
                        <td>
                            <input type="email" name="ptp_support_email"
                                value="<?php echo esc_attr(get_option('ptp_support_email', 'info@ptpsummercamps.com')); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Support Phone</th>
                        <td>
                            <input type="tel" name="ptp_support_phone"
                                value="<?php echo esc_attr(get_option('ptp_support_phone', '')); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Support Hours</th>
                        <td>
                            <input type="text" name="ptp_support_hours"
                                value="<?php echo esc_attr(get_option('ptp_support_hours', 'Mon-Fri 9am-5pm EST')); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Render promotions page
     */
    public function render_promotions_page() {
        global $wpdb;

        // Handle form submissions
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_promo_action'])) {
            check_admin_referer('ptp_promotions');

            if ($_POST['ptp_promo_action'] === 'add') {
                $wpdb->insert(
                    $this->promotions_table,
                    array(
                        'title'            => sanitize_text_field($_POST['title']),
                        'body'             => sanitize_textarea_field($_POST['body']),
                        'cta_text'         => sanitize_text_field($_POST['cta_text']),
                        'cta_url'          => esc_url_raw($_POST['cta_url']),
                        'image_url'        => esc_url_raw($_POST['image_url']),
                        'background_color' => sanitize_hex_color($_POST['background_color']) ?: '#2563eb',
                        'start_date'       => $_POST['start_date'] ? sanitize_text_field($_POST['start_date']) : null,
                        'end_date'         => $_POST['end_date'] ? sanitize_text_field($_POST['end_date']) : null,
                        'priority'         => absint($_POST['priority']),
                        'is_active'        => isset($_POST['is_active']) ? 1 : 0,
                        'created_at'       => current_time('mysql'),
                        'updated_at'       => current_time('mysql'),
                    ),
                    array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s')
                );
                echo '<div class="notice notice-success"><p>Promotion added!</p></div>';
            } elseif ($_POST['ptp_promo_action'] === 'delete' && isset($_POST['promo_id'])) {
                $wpdb->delete($this->promotions_table, array('id' => absint($_POST['promo_id'])), array('%d'));
                echo '<div class="notice notice-success"><p>Promotion deleted!</p></div>';
            }
        }

        // Get all promotions
        $promotions = $wpdb->get_results("SELECT * FROM {$this->promotions_table} ORDER BY priority DESC, created_at DESC", ARRAY_A);
        ?>
        <div class="wrap">
            <h1>Mobile App Promotions</h1>

            <h2>Add New Promotion</h2>
            <form method="post">
                <?php wp_nonce_field('ptp_promotions'); ?>
                <input type="hidden" name="ptp_promo_action" value="add">

                <table class="form-table">
                    <tr>
                        <th scope="row">Title *</th>
                        <td><input type="text" name="title" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th scope="row">Body</th>
                        <td><textarea name="body" rows="3" class="large-text"></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row">CTA Text</th>
                        <td><input type="text" name="cta_text" class="regular-text" placeholder="Learn More"></td>
                    </tr>
                    <tr>
                        <th scope="row">CTA URL</th>
                        <td><input type="url" name="cta_url" class="large-text"></td>
                    </tr>
                    <tr>
                        <th scope="row">Image URL</th>
                        <td><input type="url" name="image_url" class="large-text"></td>
                    </tr>
                    <tr>
                        <th scope="row">Background Color</th>
                        <td><input type="color" name="background_color" value="#2563eb"></td>
                    </tr>
                    <tr>
                        <th scope="row">Start Date</th>
                        <td><input type="datetime-local" name="start_date"></td>
                    </tr>
                    <tr>
                        <th scope="row">End Date</th>
                        <td><input type="datetime-local" name="end_date"></td>
                    </tr>
                    <tr>
                        <th scope="row">Priority</th>
                        <td><input type="number" name="priority" value="0" min="0" max="100"></td>
                    </tr>
                    <tr>
                        <th scope="row">Active</th>
                        <td><input type="checkbox" name="is_active" value="1" checked></td>
                    </tr>
                </table>

                <?php submit_button('Add Promotion'); ?>
            </form>

            <h2>Existing Promotions</h2>
            <?php if (empty($promotions)) : ?>
                <p>No promotions yet.</p>
            <?php else : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Priority</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Active</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($promotions as $promo) : ?>
                            <tr>
                                <td><?php echo esc_html($promo['title']); ?></td>
                                <td><?php echo esc_html($promo['priority']); ?></td>
                                <td><?php echo $promo['start_date'] ? esc_html($promo['start_date']) : '—'; ?></td>
                                <td><?php echo $promo['end_date'] ? esc_html($promo['end_date']) : '—'; ?></td>
                                <td><?php echo $promo['is_active'] ? '✓' : '✗'; ?></td>
                                <td>
                                    <form method="post" style="display:inline">
                                        <?php wp_nonce_field('ptp_promotions'); ?>
                                        <input type="hidden" name="ptp_promo_action" value="delete">
                                        <input type="hidden" name="promo_id" value="<?php echo esc_attr($promo['id']); ?>">
                                        <button type="submit" class="button button-link-delete"
                                            onclick="return confirm('Delete this promotion?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    // =========================================================================
    // STATIC HELPER METHODS
    // =========================================================================

    /**
     * Get device tokens for a user
     */
    public static function get_user_devices($user_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ptp_mobile_devices';

        return $wpdb->get_results($wpdb->prepare(
            "SELECT token, platform FROM {$table} WHERE user_id = %d",
            $user_id
        ), ARRAY_A);
    }

    /**
     * Get all device tokens
     */
    public static function get_all_devices() {
        global $wpdb;
        $table = $wpdb->prefix . 'ptp_mobile_devices';

        return $wpdb->get_results(
            "SELECT user_id, token, platform FROM {$table}",
            ARRAY_A
        );
    }
}

// Initialize the plugin
new PTP_Mobile_API();

/**
 * Plugin deactivation cleanup
 */
register_deactivation_hook(__FILE__, function() {
    // Nothing to do on deactivation
});
