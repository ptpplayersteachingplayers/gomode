<?php
/**
 * PTP Mobile API - Real-time Sync Webhooks (Phase 2)
 *
 * Handles syncing WordPress events to the real-time messaging backend.
 * Supports Supabase, Firebase, or custom webhook endpoints.
 *
 * Add this file to your WordPress plugin directory and include it in ptp-mobile-api-v2.php
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * PTP Real-time Sync Class
 *
 * Hooks into WordPress/WooCommerce events and syncs to the real-time backend.
 */
class PTP_Realtime_Sync {

    /**
     * Real-time backend URL
     */
    private $backend_url;

    /**
     * API key for authentication
     */
    private $api_key;

    /**
     * Whether sync is enabled
     */
    private $is_enabled;

    /**
     * Constructor
     */
    public function __construct() {
        $this->backend_url = get_option('ptp_realtime_backend_url', '');
        $this->api_key = get_option('ptp_realtime_api_key', '');
        $this->is_enabled = !empty($this->backend_url) && !empty($this->api_key);

        if ($this->is_enabled) {
            $this->register_hooks();
        }
    }

    /**
     * Register all WordPress hooks
     */
    private function register_hooks() {
        // User events
        add_action('user_register', array($this, 'on_user_created'), 10, 1);
        add_action('profile_update', array($this, 'on_user_updated'), 10, 2);

        // WooCommerce order events
        add_action('woocommerce_order_status_changed', array($this, 'on_order_status_changed'), 10, 4);
        add_action('woocommerce_new_order', array($this, 'on_new_order'), 10, 2);
        add_action('woocommerce_thankyou', array($this, 'on_order_completed'), 10, 1);

        // Camp/product events
        add_action('save_post_product', array($this, 'on_product_saved'), 10, 3);

        // Private training booking events (custom hook)
        add_action('ptp_training_booked', array($this, 'on_training_booked'), 10, 3);
        add_action('ptp_training_cancelled', array($this, 'on_training_cancelled'), 10, 2);
    }

    // =========================================================================
    // USER EVENTS
    // =========================================================================

    /**
     * Sync new user to real-time backend
     */
    public function on_user_created($user_id) {
        $user = get_userdata($user_id);
        if (!$user) return;

        $payload = array(
            'event' => 'user.created',
            'data' => array(
                'id' => $user_id,
                'email' => $user->user_email,
                'name' => $user->display_name,
                'role' => $this->get_user_role($user),
                'created_at' => $user->user_registered,
            ),
        );

        $this->send_webhook($payload);

        // Create default support conversation for the user
        $this->create_support_conversation($user_id);
    }

    /**
     * Sync user update to real-time backend
     */
    public function on_user_updated($user_id, $old_user_data) {
        $user = get_userdata($user_id);
        if (!$user) return;

        $payload = array(
            'event' => 'user.updated',
            'data' => array(
                'id' => $user_id,
                'email' => $user->user_email,
                'name' => $user->display_name,
                'role' => $this->get_user_role($user),
            ),
        );

        $this->send_webhook($payload);
    }

    // =========================================================================
    // ORDER EVENTS
    // =========================================================================

    /**
     * Handle new order creation
     */
    public function on_new_order($order_id, $order) {
        if (!$order) {
            $order = wc_get_order($order_id);
        }
        if (!$order) return;

        $user_id = $order->get_customer_id();
        if (!$user_id) return;

        // Check if order contains camp/clinic products
        $camp_items = $this->get_camp_items_from_order($order);
        if (empty($camp_items)) return;

        $payload = array(
            'event' => 'order.created',
            'data' => array(
                'order_id' => $order_id,
                'user_id' => $user_id,
                'status' => $order->get_status(),
                'camps' => $camp_items,
                'created_at' => $order->get_date_created()->format('c'),
            ),
        );

        $this->send_webhook($payload);
    }

    /**
     * Handle order status change
     */
    public function on_order_status_changed($order_id, $old_status, $new_status, $order) {
        $user_id = $order->get_customer_id();
        if (!$user_id) return;

        $camp_items = $this->get_camp_items_from_order($order);
        if (empty($camp_items)) return;

        $payload = array(
            'event' => 'order.status_changed',
            'data' => array(
                'order_id' => $order_id,
                'user_id' => $user_id,
                'old_status' => $old_status,
                'new_status' => $new_status,
                'camps' => $camp_items,
            ),
        );

        $this->send_webhook($payload);

        // Send system message to support conversation
        if ($new_status === 'completed' || $new_status === 'processing') {
            foreach ($camp_items as $camp) {
                $this->send_system_message(
                    $user_id,
                    'support',
                    sprintf('✅ You\'re confirmed for %s on %s!', $camp['name'], $camp['date'])
                );
            }
        }
    }

    /**
     * Handle order completion (thank you page)
     */
    public function on_order_completed($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        $user_id = $order->get_customer_id();
        if (!$user_id) return;

        // Update user metadata for the real-time backend
        $payload = array(
            'event' => 'user.has_booking',
            'data' => array(
                'user_id' => $user_id,
                'has_upcoming_camp' => true,
                'order_id' => $order_id,
            ),
        );

        $this->send_webhook($payload);
    }

    // =========================================================================
    // PRODUCT/CAMP EVENTS
    // =========================================================================

    /**
     * Handle product save (camp updates)
     */
    public function on_product_saved($post_id, $post, $update) {
        if ($post->post_status !== 'publish') return;

        $product = wc_get_product($post_id);
        if (!$product) return;

        // Check if it's a camp/clinic
        $categories = wp_get_post_terms($post_id, 'product_cat', array('fields' => 'slugs'));
        $is_camp = array_intersect($categories, array('summer', 'winter-clinics'));
        if (empty($is_camp)) return;

        $stock_quantity = $product->get_stock_quantity();
        $stock_status = $product->get_stock_status();

        $payload = array(
            'event' => 'camp.updated',
            'data' => array(
                'id' => $post_id,
                'name' => $product->get_name(),
                'available_seats' => $stock_quantity ?? 0,
                'is_waitlist_only' => $stock_status === 'onbackorder',
                'date' => get_post_meta($post_id, '_camp_date', true),
                'location' => get_post_meta($post_id, '_camp_location', true),
            ),
        );

        $this->send_webhook($payload);

        // If camp is almost full, notify waitlist users
        if ($stock_quantity !== null && $stock_quantity <= 3 && $stock_quantity > 0) {
            $this->notify_waitlist_availability($post_id, $stock_quantity);
        }
    }

    // =========================================================================
    // PRIVATE TRAINING EVENTS
    // =========================================================================

    /**
     * Handle private training booking
     */
    public function on_training_booked($booking_id, $user_id, $trainer_id) {
        $payload = array(
            'event' => 'training.booked',
            'data' => array(
                'booking_id' => $booking_id,
                'user_id' => $user_id,
                'trainer_id' => $trainer_id,
            ),
        );

        $this->send_webhook($payload);

        // Create trainer conversation
        $this->create_trainer_conversation($user_id, $trainer_id, $booking_id);
    }

    /**
     * Handle private training cancellation
     */
    public function on_training_cancelled($booking_id, $user_id) {
        $payload = array(
            'event' => 'training.cancelled',
            'data' => array(
                'booking_id' => $booking_id,
                'user_id' => $user_id,
            ),
        );

        $this->send_webhook($payload);
    }

    // =========================================================================
    // CONVERSATION HELPERS
    // =========================================================================

    /**
     * Create default support conversation for new user
     */
    private function create_support_conversation($user_id) {
        $payload = array(
            'event' => 'conversation.create',
            'data' => array(
                'type' => 'parent-support',
                'participant_ids' => array($user_id, 0), // 0 = support
            ),
        );

        $this->send_webhook($payload);

        // Send welcome message
        $this->send_system_message(
            $user_id,
            'support',
            'Welcome to PTP Soccer Camps! 👋 We\'re here to help with any questions about our camps, clinics, or private training. Just send us a message!'
        );
    }

    /**
     * Create trainer conversation after booking
     */
    private function create_trainer_conversation($user_id, $trainer_id, $booking_id) {
        $trainer = get_post($trainer_id);
        $trainer_name = $trainer ? $trainer->post_title : 'Your Trainer';

        $payload = array(
            'event' => 'conversation.create',
            'data' => array(
                'type' => 'parent-trainer',
                'participant_ids' => array($user_id, $trainer_id),
                'booking_id' => $booking_id,
            ),
        );

        $this->send_webhook($payload);

        // Send intro message
        $this->send_system_message(
            $user_id,
            'trainer',
            sprintf('You can now message %s directly about your upcoming training session!', $trainer_name)
        );
    }

    /**
     * Send system message to a conversation
     */
    private function send_system_message($user_id, $conversation_type, $message) {
        $payload = array(
            'event' => 'message.system',
            'data' => array(
                'user_id' => $user_id,
                'conversation_type' => $conversation_type,
                'text' => $message,
                'is_system' => true,
            ),
        );

        $this->send_webhook($payload);
    }

    /**
     * Notify waitlist users when spots become available
     */
    private function notify_waitlist_availability($product_id, $available_seats) {
        $product = wc_get_product($product_id);
        if (!$product) return;

        $payload = array(
            'event' => 'camp.spots_available',
            'data' => array(
                'camp_id' => $product_id,
                'camp_name' => $product->get_name(),
                'available_seats' => $available_seats,
                'message' => sprintf('%d spots just opened up for %s!', $available_seats, $product->get_name()),
            ),
        );

        $this->send_webhook($payload);
    }

    // =========================================================================
    // UTILITY METHODS
    // =========================================================================

    /**
     * Get user's primary role
     */
    private function get_user_role($user) {
        $roles = $user->roles;
        if (in_array('administrator', $roles)) return 'admin';
        if (in_array('ptp_trainer', $roles)) return 'trainer';
        return 'parent';
    }

    /**
     * Get camp items from an order
     */
    private function get_camp_items_from_order($order) {
        $camp_items = array();

        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'slugs'));
            $is_camp = array_intersect($categories, array('summer', 'winter-clinics'));

            if (!empty($is_camp)) {
                $camp_items[] = array(
                    'product_id' => $product_id,
                    'name' => $item->get_name(),
                    'date' => get_post_meta($product_id, '_camp_date', true),
                    'location' => get_post_meta($product_id, '_camp_location', true),
                );
            }
        }

        return $camp_items;
    }

    /**
     * Send webhook to real-time backend
     */
    private function send_webhook($payload) {
        if (!$this->is_enabled) {
            return false;
        }

        $payload['timestamp'] = current_time('c');
        $payload['source'] = 'wordpress';

        $response = wp_remote_post($this->backend_url, array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key,
                'X-PTP-Source' => 'wordpress',
            ),
            'body' => json_encode($payload),
            'timeout' => 10,
            'blocking' => false, // Don't wait for response
        ));

        if (is_wp_error($response)) {
            error_log('PTP Realtime Sync Error: ' . $response->get_error_message());
            return false;
        }

        return true;
    }
}

// Initialize the sync handler
add_action('plugins_loaded', function() {
    new PTP_Realtime_Sync();
});

// =========================================================================
// ADMIN SETTINGS
// =========================================================================

/**
 * Add real-time sync settings to admin page
 */
add_action('admin_init', function() {
    register_setting('ptp_mobile_settings', 'ptp_realtime_backend_url');
    register_setting('ptp_mobile_settings', 'ptp_realtime_api_key');
});

/**
 * Render real-time sync settings fields
 * Add this to your admin page render function
 */
function ptp_render_realtime_settings() {
    ?>
    <h2>Real-time Sync Settings (Phase 2)</h2>
    <p class="description">Configure the real-time messaging backend (Supabase, Firebase, etc.)</p>
    <table class="form-table">
        <tr>
            <th scope="row">Backend URL</th>
            <td>
                <input type="url" name="ptp_realtime_backend_url"
                    value="<?php echo esc_attr(get_option('ptp_realtime_backend_url', '')); ?>"
                    class="large-text"
                    placeholder="https://your-project.supabase.co/functions/v1/webhook">
                <p class="description">The webhook endpoint URL for your real-time backend</p>
            </td>
        </tr>
        <tr>
            <th scope="row">API Key</th>
            <td>
                <input type="password" name="ptp_realtime_api_key"
                    value="<?php echo esc_attr(get_option('ptp_realtime_api_key', '')); ?>"
                    class="regular-text">
                <p class="description">Authentication key for the webhook</p>
            </td>
        </tr>
    </table>
    <?php
}
