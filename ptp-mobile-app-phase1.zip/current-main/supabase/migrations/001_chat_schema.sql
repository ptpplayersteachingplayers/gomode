-- =============================================================================
-- PTP Mobile App - Supabase Schema (Phase 2)
-- =============================================================================
-- Run this in your Supabase SQL editor or as a migration
-- =============================================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- USERS TABLE
-- Synced from WordPress, stores messaging-specific data
-- =============================================================================

CREATE TABLE IF NOT EXISTS public.users (
  id SERIAL PRIMARY KEY,
  wp_user_id INTEGER UNIQUE NOT NULL,
  email TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'parent' CHECK (role IN ('parent', 'trainer', 'admin', 'support')),
  avatar_url TEXT,
  is_online BOOLEAN DEFAULT FALSE,
  last_seen_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast lookup by WordPress user ID
CREATE INDEX IF NOT EXISTS idx_users_wp_user_id ON public.users(wp_user_id);

-- =============================================================================
-- CONVERSATIONS TABLE
-- =============================================================================

CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type TEXT NOT NULL CHECK (type IN ('parent-support', 'parent-trainer', 'group')),
  participant_ids INTEGER[] NOT NULL,
  camp_id INTEGER,
  booking_id INTEGER,
  is_archived BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for finding conversations by participant
CREATE INDEX IF NOT EXISTS idx_conversations_participants ON public.conversations USING GIN(participant_ids);

-- Index for filtering by type
CREATE INDEX IF NOT EXISTS idx_conversations_type ON public.conversations(type);

-- =============================================================================
-- MESSAGES TABLE
-- =============================================================================

CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  seen_by INTEGER[] DEFAULT '{}',
  is_system BOOLEAN DEFAULT FALSE,
  attachments JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fetching messages by conversation
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON public.messages(conversation_id, created_at);

-- Index for finding unread messages
CREATE INDEX IF NOT EXISTS idx_messages_seen_by ON public.messages USING GIN(seen_by);

-- =============================================================================
-- FUNCTIONS
-- =============================================================================

-- Function to update conversation's updated_at when a message is sent
CREATE OR REPLACE FUNCTION update_conversation_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.conversations
  SET updated_at = NOW()
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-update conversation timestamp
DROP TRIGGER IF EXISTS on_message_sent ON public.messages;
CREATE TRIGGER on_message_sent
AFTER INSERT ON public.messages
FOR EACH ROW
EXECUTE FUNCTION update_conversation_timestamp();

-- Function to mark messages as seen
CREATE OR REPLACE FUNCTION mark_messages_seen(
  p_message_ids UUID[],
  p_user_id INTEGER
)
RETURNS VOID AS $$
BEGIN
  UPDATE public.messages
  SET seen_by = ARRAY(SELECT DISTINCT unnest(seen_by || ARRAY[p_user_id]))
  WHERE id = ANY(p_message_ids)
    AND NOT (p_user_id = ANY(seen_by));
END;
$$ LANGUAGE plpgsql;

-- Function to get unread count for a user
CREATE OR REPLACE FUNCTION get_unread_count(p_user_id INTEGER)
RETURNS TABLE(conversation_id UUID, unread_count BIGINT) AS $$
BEGIN
  RETURN QUERY
  SELECT
    m.conversation_id,
    COUNT(*) as unread_count
  FROM public.messages m
  JOIN public.conversations c ON c.id = m.conversation_id
  WHERE p_user_id = ANY(c.participant_ids)
    AND NOT (p_user_id = ANY(m.seen_by))
    AND m.sender_id != p_user_id
  GROUP BY m.conversation_id;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- ROW LEVEL SECURITY
-- =============================================================================

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Users can read their own data
CREATE POLICY "Users can read own data" ON public.users
  FOR SELECT
  USING (true); -- All users can see other users (for participant info)

-- Users can update their own data
CREATE POLICY "Users can update own data" ON public.users
  FOR UPDATE
  USING (auth.uid()::text = wp_user_id::text);

-- Users can read conversations they're part of
CREATE POLICY "Users can read their conversations" ON public.conversations
  FOR SELECT
  USING (
    auth.uid()::integer = ANY(participant_ids)
    OR EXISTS (
      SELECT 1 FROM public.users
      WHERE wp_user_id = auth.uid()::integer
      AND role IN ('admin', 'support')
    )
  );

-- Users can create conversations
CREATE POLICY "Users can create conversations" ON public.conversations
  FOR INSERT
  WITH CHECK (auth.uid()::integer = ANY(participant_ids));

-- Users can read messages in their conversations
CREATE POLICY "Users can read messages in their conversations" ON public.messages
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.conversations
      WHERE id = conversation_id
      AND auth.uid()::integer = ANY(participant_ids)
    )
    OR EXISTS (
      SELECT 1 FROM public.users
      WHERE wp_user_id = auth.uid()::integer
      AND role IN ('admin', 'support')
    )
  );

-- Users can send messages to their conversations
CREATE POLICY "Users can send messages to their conversations" ON public.messages
  FOR INSERT
  WITH CHECK (
    sender_id = auth.uid()::integer
    AND EXISTS (
      SELECT 1 FROM public.conversations
      WHERE id = conversation_id
      AND auth.uid()::integer = ANY(participant_ids)
    )
  );

-- Users can update seen_by on messages
CREATE POLICY "Users can mark messages as seen" ON public.messages
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.conversations
      WHERE id = conversation_id
      AND auth.uid()::integer = ANY(participant_ids)
    )
  );

-- =============================================================================
-- REALTIME
-- =============================================================================

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;

-- =============================================================================
-- SEED DATA (Optional)
-- =============================================================================

-- Insert the "PTP Support" user (id = 0 represents the support team)
INSERT INTO public.users (id, wp_user_id, email, name, role)
VALUES (0, 0, 'support@ptpsummercamps.com', 'PTP Support', 'support')
ON CONFLICT (wp_user_id) DO NOTHING;

-- Reset the sequence to avoid conflicts
SELECT setval('users_id_seq', COALESCE((SELECT MAX(id) FROM public.users), 1) + 1, false);
