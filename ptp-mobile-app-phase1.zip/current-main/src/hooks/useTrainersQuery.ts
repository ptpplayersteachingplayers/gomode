/**
 * PTP Mobile App - Trainers React Query Hooks
 *
 * Features:
 * - Automatic caching with longer stale time (trainers change rarely)
 * - Filtering by city/specialty
 * - Individual trainer lookup with cache reuse
 */

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { getTrainers, ApiClientError } from '../api/client';
import { queryKeys, STALE_TIMES, TrainerFilters } from '../api/queryClient';
import { Trainer } from '../types';
import { useAuth } from '../context/AuthContext';

// =============================================================================
// Trainers List Hook
// =============================================================================

interface UseTrainersOptions {
  /** Filter trainers */
  filters?: TrainerFilters;

  /** Whether to fetch immediately */
  enabled?: boolean;

  /** Override default stale time */
  staleTime?: number;
}

interface UseTrainersReturn {
  trainers: Trainer[];
  isLoading: boolean;
  isRefreshing: boolean;
  isFetching: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  isStale: boolean;
  dataUpdatedAt: number | undefined;
}

/**
 * Hook for fetching trainers with React Query
 *
 * @example
 * ```tsx
 * // Basic usage
 * const { trainers, isLoading } = useTrainersQuery();
 *
 * // With filters
 * const { trainers } = useTrainersQuery({
 *   filters: { city: 'Philadelphia', specialty: 'Finishing' }
 * });
 * ```
 */
export function useTrainersQuery(options: UseTrainersOptions = {}): UseTrainersReturn {
  const { filters, enabled = true, staleTime = STALE_TIMES.trainers } = options;
  const { logout } = useAuth();

  const query = useQuery({
    queryKey: queryKeys.trainers.list(filters),
    queryFn: async () => {
      const allTrainers = await getTrainers();

      // Apply client-side filters if provided
      if (!filters) return allTrainers;

      return allTrainers.filter((trainer) => {
        if (filters.city && !trainer.city.toLowerCase().includes(filters.city.toLowerCase())) {
          return false;
        }
        if (filters.specialty && !trainer.specialty.toLowerCase().includes(filters.specialty.toLowerCase())) {
          return false;
        }
        if (filters.search) {
          const searchLower = filters.search.toLowerCase();
          const matchesName = trainer.name.toLowerCase().includes(searchLower);
          const matchesCollege = trainer.college.toLowerCase().includes(searchLower);
          const matchesBio = trainer.bio.toLowerCase().includes(searchLower);
          if (!matchesName && !matchesCollege && !matchesBio) return false;
        }
        return true;
      });
    },
    enabled,
    staleTime,
    throwOnError: (error) => {
      if (error instanceof ApiClientError && error.isSessionExpired()) {
        logout();
        return false;
      }
      return false;
    },
  });

  return {
    trainers: query.data ?? [],
    isLoading: query.isLoading,
    isRefreshing: query.isRefetching && !query.isLoading,
    isFetching: query.isFetching,
    error: query.error?.message ?? null,
    refetch: async () => {
      await query.refetch();
    },
    isStale: query.isStale,
    dataUpdatedAt: query.dataUpdatedAt,
  };
}

// =============================================================================
// Single Trainer Hook
// =============================================================================

interface UseTrainerOptions {
  trainerId: number;
  enabled?: boolean;
}

/**
 * Hook for fetching a single trainer by ID
 * Uses the trainers list cache when available
 */
export function useTrainerQuery({ trainerId, enabled = true }: UseTrainerOptions) {
  const queryClient = useQueryClient();

  return useQuery({
    queryKey: queryKeys.trainers.detail(trainerId),
    queryFn: async () => {
      // Try to get from the list cache first
      const cachedTrainers = queryClient.getQueryData<Trainer[]>(
        queryKeys.trainers.list()
      );
      const cachedTrainer = cachedTrainers?.find((t) => t.id === trainerId);

      if (cachedTrainer) {
        return cachedTrainer;
      }

      // Otherwise fetch all trainers and find
      const allTrainers = await getTrainers();
      const trainer = allTrainers.find((t) => t.id === trainerId);

      if (!trainer) {
        throw new Error('Trainer not found');
      }

      return trainer;
    },
    enabled: enabled && trainerId > 0,
    staleTime: STALE_TIMES.trainers,
  });
}

// =============================================================================
// Trainers by IDs Hook
// =============================================================================

/**
 * Hook for fetching multiple trainers by their IDs
 * Useful for showing trainers assigned to a camp
 */
export function useTrainersByIdsQuery(trainerIds: number[], enabled = true) {
  const queryClient = useQueryClient();

  return useQuery({
    queryKey: ['trainers', 'byIds', trainerIds],
    queryFn: async () => {
      // Try to get from cache first
      const cachedTrainers = queryClient.getQueryData<Trainer[]>(
        queryKeys.trainers.list()
      );

      if (cachedTrainers) {
        return trainerIds
          .map((id) => cachedTrainers.find((t) => t.id === id))
          .filter((t): t is Trainer => t !== undefined);
      }

      // Otherwise fetch all and filter
      const allTrainers = await getTrainers();
      return trainerIds
        .map((id) => allTrainers.find((t) => t.id === id))
        .filter((t): t is Trainer => t !== undefined);
    },
    enabled: enabled && trainerIds.length > 0,
    staleTime: STALE_TIMES.trainers,
  });
}

// =============================================================================
// Prefetch Helper
// =============================================================================

/**
 * Prefetch trainers data
 */
export function usePrefetchTrainers() {
  const queryClient = useQueryClient();

  return () => {
    queryClient.prefetchQuery({
      queryKey: queryKeys.trainers.list(),
      queryFn: getTrainers,
      staleTime: STALE_TIMES.trainers,
    });
  };
}

// =============================================================================
// Export
// =============================================================================

export default useTrainersQuery;
