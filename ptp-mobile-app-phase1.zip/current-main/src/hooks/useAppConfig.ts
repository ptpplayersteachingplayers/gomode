/**
 * PTP Mobile App - App Config React Query Hook
 *
 * Features:
 * - Feature flags for enabling/disabling app features
 * - Promotional banners
 * - Version gating for forced updates
 * - Long cache time (config rarely changes)
 */

import { useQuery, useQueryClient } from '@tanstack/react-query';
import * as Application from 'expo-application';
import { Platform, Linking } from 'react-native';
import apiClient from '../api/client';
import { queryKeys, STALE_TIMES } from '../api/queryClient';
import {
  AppConfig,
  FeatureFlags,
  PromoBanner,
  VersionConfig,
  Market,
} from '../types/extended';

// =============================================================================
// Default App Config (fallback if API fails)
// =============================================================================

const DEFAULT_CONFIG: AppConfig = {
  features: {
    enablePrivateTraining: true,
    enableMessaging: false, // Will be true in Phase 2
    enableWaitlist: true,
    enablePushNotifications: true,
    enableNearbyCamps: true,
    enableTrainerReviews: false,
  },
  promotions: [],
  versioning: {
    minSupportedVersion: '1.0.0',
    latestVersion: '1.0.0',
    updateUrl: {
      ios: 'https://apps.apple.com/app/ptp-soccer-camps/id000000000',
      android: 'https://play.google.com/store/apps/details?id=com.ptpsummercamps.app',
    },
  },
  markets: [
    { code: 'PA', name: 'Pennsylvania', isActive: true },
    { code: 'NJ', name: 'New Jersey', isActive: true },
    { code: 'DE', name: 'Delaware', isActive: true },
    { code: 'MD', name: 'Maryland', isActive: true },
    { code: 'NY', name: 'New York', isActive: true },
  ],
  support: {
    email: 'info@ptpsummercamps.com',
    phone: '(215) 555-1234',
    hours: 'Mon-Fri 9am-5pm EST',
  },
  updatedAt: new Date().toISOString(),
};

// =============================================================================
// API Function
// =============================================================================

/**
 * Fetch app config from WordPress API
 */
async function getAppConfig(): Promise<AppConfig> {
  try {
    const response = await apiClient.get<AppConfig>('/ptp/v1/app-config');
    return {
      ...DEFAULT_CONFIG,
      ...response.data,
      features: {
        ...DEFAULT_CONFIG.features,
        ...response.data.features,
      },
    };
  } catch (error) {
    // Return default config if endpoint doesn't exist yet
    console.warn('App config endpoint not available, using defaults');
    return DEFAULT_CONFIG;
  }
}

// =============================================================================
// App Config Hook
// =============================================================================

interface UseAppConfigReturn {
  config: AppConfig;
  features: FeatureFlags;
  promotions: PromoBanner[];
  markets: Market[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * Hook for fetching app configuration
 *
 * @example
 * ```tsx
 * const { features, promotions } = useAppConfig();
 *
 * if (features.enableMessaging) {
 *   // Show messaging UI
 * }
 * ```
 */
export function useAppConfig(): UseAppConfigReturn {
  const query = useQuery({
    queryKey: queryKeys.appConfig,
    queryFn: getAppConfig,
    staleTime: STALE_TIMES.appConfig,
    // Use fallback data while loading
    placeholderData: DEFAULT_CONFIG,
    // Keep trying even if fails (might be network issue)
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });

  const config = query.data ?? DEFAULT_CONFIG;

  return {
    config,
    features: config.features,
    promotions: config.promotions,
    markets: config.markets,
    isLoading: query.isLoading,
    error: query.error?.message ?? null,
    refetch: async () => {
      await query.refetch();
    },
  };
}

// =============================================================================
// Feature Flag Hook
// =============================================================================

/**
 * Hook for checking a specific feature flag
 *
 * @example
 * ```tsx
 * const isMessagingEnabled = useFeatureFlag('enableMessaging');
 * ```
 */
export function useFeatureFlag(flag: keyof FeatureFlags): boolean {
  const { features } = useAppConfig();
  return features[flag];
}

// =============================================================================
// Active Promotions Hook
// =============================================================================

/**
 * Hook for getting currently active promotions
 * Filters out expired/future promotions and sorts by priority
 */
export function useActivePromotions(): PromoBanner[] {
  const { promotions } = useAppConfig();
  const now = new Date();

  return promotions
    .filter((promo) => {
      // Check start date
      if (promo.startDate && new Date(promo.startDate) > now) {
        return false;
      }
      // Check end date
      if (promo.endDate && new Date(promo.endDate) < now) {
        return false;
      }
      return true;
    })
    .sort((a, b) => b.priority - a.priority);
}

// =============================================================================
// Version Check Hook
// =============================================================================

interface VersionCheckResult {
  /** App needs to be updated */
  needsUpdate: boolean;

  /** Force update (below minimum version) */
  isForceUpdate: boolean;

  /** Optional update available */
  hasOptionalUpdate: boolean;

  /** Current app version */
  currentVersion: string;

  /** Latest available version */
  latestVersion: string;

  /** Open store to update */
  openStore: () => void;
}

/**
 * Hook for checking app version against required versions
 *
 * @example
 * ```tsx
 * const { needsUpdate, isForceUpdate, openStore } = useVersionCheck();
 *
 * if (isForceUpdate) {
 *   // Show blocking update screen
 * }
 * ```
 */
export function useVersionCheck(): VersionCheckResult {
  const { config } = useAppConfig();
  const versioning = config.versioning;

  const currentVersion = Application.nativeApplicationVersion ?? '1.0.0';
  const minVersion = versioning.minSupportedVersion;
  const latestVersion = versioning.latestVersion;

  const compareVersions = (a: string, b: string): number => {
    const aParts = a.split('.').map(Number);
    const bParts = b.split('.').map(Number);

    for (let i = 0; i < Math.max(aParts.length, bParts.length); i++) {
      const aVal = aParts[i] ?? 0;
      const bVal = bParts[i] ?? 0;
      if (aVal < bVal) return -1;
      if (aVal > bVal) return 1;
    }
    return 0;
  };

  const isForceUpdate = compareVersions(currentVersion, minVersion) < 0;
  const hasOptionalUpdate = compareVersions(currentVersion, latestVersion) < 0;

  const openStore = () => {
    const url = Platform.OS === 'ios'
      ? versioning.updateUrl.ios
      : versioning.updateUrl.android;
    Linking.openURL(url);
  };

  return {
    needsUpdate: isForceUpdate || hasOptionalUpdate,
    isForceUpdate,
    hasOptionalUpdate,
    currentVersion,
    latestVersion,
    openStore,
  };
}

// =============================================================================
// Prefetch Helper
// =============================================================================

/**
 * Prefetch app config (call on app start)
 */
export function usePrefetchAppConfig() {
  const queryClient = useQueryClient();

  return () => {
    queryClient.prefetchQuery({
      queryKey: queryKeys.appConfig,
      queryFn: getAppConfig,
      staleTime: STALE_TIMES.appConfig,
    });
  };
}

// =============================================================================
// Export
// =============================================================================

export { useAppConfig, useFeatureFlag, useActivePromotions, useVersionCheck };
export default useAppConfig;
