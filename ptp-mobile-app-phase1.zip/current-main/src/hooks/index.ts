/**
 * PTP Mobile App - Hooks Index
 *
 * Export all custom hooks from a single location
 */

// =============================================================================
// Legacy Hooks (kept for backwards compatibility during migration)
// =============================================================================

export { useApi } from './useApi';
export { useCamps } from './useCamps';
export { useTrainers } from './useTrainers';
export { useSessions } from './useSessions';

// =============================================================================
// React Query Hooks (Phase 1+)
// =============================================================================

// Camps
export {
  useCampsQuery,
  useCampQuery,
  useNearbyCampsQuery,
  usePrefetchCamps,
} from './useCampsQuery';

// Trainers
export {
  useTrainersQuery,
  useTrainerQuery,
  useTrainersByIdsQuery,
  usePrefetchTrainers,
} from './useTrainersQuery';

// Sessions & User
export {
  useSessionsQuery,
  useUserQuery,
  useHomeScreenData,
  usePrefetchUserData,
} from './useSessionsQuery';

// App Config & Feature Flags
export {
  useAppConfig,
  useFeatureFlag,
  useActivePromotions,
  useVersionCheck,
  usePrefetchAppConfig,
} from './useAppConfig';
