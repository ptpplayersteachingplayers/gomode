/**
 * PTP Mobile App - Camps React Query Hooks
 *
 * Features:
 * - Automatic caching and background refresh
 * - Stale-while-revalidate behavior
 * - Optimistic updates
 * - Type-safe query keys
 */

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { getCamps, ApiClientError } from '../api/client';
import { queryKeys, STALE_TIMES, CampFilters } from '../api/queryClient';
import { Camp } from '../types';
import { EnhancedCamp, NearbyCampsParams, NearbyCampsResponse } from '../types/extended';
import { useAuth } from '../context/AuthContext';

// =============================================================================
// Camps List Hook
// =============================================================================

interface UseCampsOptions {
  /** Filter camps by state, category, etc. */
  filters?: CampFilters;

  /** Whether to fetch immediately */
  enabled?: boolean;

  /** Override default stale time */
  staleTime?: number;
}

interface UseCampsReturn {
  camps: Camp[];
  isLoading: boolean;
  isRefreshing: boolean;
  isFetching: boolean;
  error: string | null;
  refetch: () => Promise<void>;

  /** Is data from cache (stale) */
  isStale: boolean;

  /** Last successful fetch time */
  dataUpdatedAt: number | undefined;
}

/**
 * Hook for fetching camps with React Query
 *
 * @example
 * ```tsx
 * // Basic usage
 * const { camps, isLoading, refetch } = useCampsQuery();
 *
 * // With filters
 * const { camps } = useCampsQuery({
 *   filters: { state: 'PA', category: 'summer' }
 * });
 * ```
 */
export function useCampsQuery(options: UseCampsOptions = {}): UseCampsReturn {
  const { filters, enabled = true, staleTime = STALE_TIMES.camps } = options;
  const { logout } = useAuth();

  const query = useQuery({
    queryKey: queryKeys.camps.list(filters),
    queryFn: async () => {
      const allCamps = await getCamps();

      // Apply client-side filters if provided
      if (!filters) return allCamps;

      return allCamps.filter((camp) => {
        if (filters.state && camp.state !== filters.state) return false;
        if (filters.category && camp.category !== filters.category) return false;
        if (filters.search) {
          const searchLower = filters.search.toLowerCase();
          const matchesName = camp.name.toLowerCase().includes(searchLower);
          const matchesLocation = camp.location.toLowerCase().includes(searchLower);
          if (!matchesName && !matchesLocation) return false;
        }
        return true;
      });
    },
    enabled,
    staleTime,
    // Handle session expiry
    throwOnError: (error) => {
      if (error instanceof ApiClientError && error.isSessionExpired()) {
        logout();
        return false;
      }
      return false;
    },
  });

  return {
    camps: query.data ?? [],
    isLoading: query.isLoading,
    isRefreshing: query.isRefetching && !query.isLoading,
    isFetching: query.isFetching,
    error: query.error?.message ?? null,
    refetch: async () => {
      await query.refetch();
    },
    isStale: query.isStale,
    dataUpdatedAt: query.dataUpdatedAt,
  };
}

// =============================================================================
// Single Camp Hook
// =============================================================================

interface UseCampOptions {
  campId: number;
  enabled?: boolean;
}

/**
 * Hook for fetching a single camp by ID
 * Uses the camps list cache when available
 */
export function useCampQuery({ campId, enabled = true }: UseCampOptions) {
  const queryClient = useQueryClient();

  return useQuery({
    queryKey: queryKeys.camps.detail(campId),
    queryFn: async () => {
      // Try to get from the list cache first
      const cachedCamps = queryClient.getQueryData<Camp[]>(
        queryKeys.camps.list()
      );
      const cachedCamp = cachedCamps?.find((c) => c.id === campId);

      if (cachedCamp) {
        return cachedCamp;
      }

      // Otherwise fetch all camps and find
      const allCamps = await getCamps();
      const camp = allCamps.find((c) => c.id === campId);

      if (!camp) {
        throw new Error('Camp not found');
      }

      return camp;
    },
    enabled: enabled && campId > 0,
    staleTime: STALE_TIMES.camps,
  });
}

// =============================================================================
// Nearby Camps Hook (for geo-filtered search)
// =============================================================================

interface UseNearbyCampsOptions extends NearbyCampsParams {
  enabled?: boolean;
}

/**
 * Hook for fetching camps near a location
 * This will call the enhanced /camps endpoint with lat/lng params
 *
 * @example
 * ```tsx
 * const { camps, isLoading } = useNearbyCampsQuery({
 *   lat: 40.0583,
 *   lng: -74.4057,
 *   radius: 25
 * });
 * ```
 */
export function useNearbyCampsQuery(options: UseNearbyCampsOptions) {
  const { lat, lng, radius = 50, category, limit, enabled = true } = options;

  return useQuery({
    queryKey: queryKeys.camps.nearby(lat, lng, radius),
    queryFn: async (): Promise<NearbyCampsResponse> => {
      // TODO: Call enhanced endpoint when available
      // For now, simulate with client-side filtering
      const allCamps = await getCamps();

      // Simple distance calculation (Haversine would be better)
      const campsWithDistance = allCamps
        .map((camp) => ({
          ...camp,
          totalSeats: 20,
          availableSeats: Math.floor(Math.random() * 20),
          isWaitlistOnly: false,
          lastUpdatedAt: new Date().toISOString(),
          // Mock distance - real implementation would use camp coordinates
          distance: Math.random() * radius,
          distanceUnit: 'miles' as const,
        }))
        .filter((camp) => camp.distance <= radius);

      // Apply category filter
      const filtered = category
        ? campsWithDistance.filter((c) => c.category === category)
        : campsWithDistance;

      // Sort by distance
      filtered.sort((a, b) => (a.distance ?? 0) - (b.distance ?? 0));

      // Apply limit
      const limited = limit ? filtered.slice(0, limit) : filtered;

      return {
        camps: limited,
        searchLocation: {
          lat,
          lng,
          radius,
          radiusUnit: 'miles',
        },
      };
    },
    enabled: enabled && lat !== 0 && lng !== 0,
    staleTime: STALE_TIMES.camps,
  });
}

// =============================================================================
// Prefetch Helpers
// =============================================================================

/**
 * Prefetch camps data (useful for preloading on app start)
 */
export function usePrefetchCamps() {
  const queryClient = useQueryClient();

  return () => {
    queryClient.prefetchQuery({
      queryKey: queryKeys.camps.list(),
      queryFn: getCamps,
      staleTime: STALE_TIMES.camps,
    });
  };
}

// =============================================================================
// Export for convenience
// =============================================================================

export default useCampsQuery;
