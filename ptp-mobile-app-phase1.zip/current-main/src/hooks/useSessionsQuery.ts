/**
 * PTP Mobile App - Sessions & User React Query Hooks
 *
 * Features:
 * - User sessions with frequent refresh (1 minute stale time)
 * - User profile data
 * - Next session helper for home screen
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getSessions, getMe, ApiClientError } from '../api/client';
import { queryKeys, STALE_TIMES } from '../api/queryClient';
import { Session, User } from '../types';
import { useAuth } from '../context/AuthContext';

// =============================================================================
// Sessions Hook
// =============================================================================

interface UseSessionsOptions {
  /** Filter by status */
  status?: 'upcoming' | 'completed' | 'cancelled';

  /** Whether to fetch immediately */
  enabled?: boolean;
}

interface UseSessionsReturn {
  sessions: Session[];
  upcomingSessions: Session[];
  completedSessions: Session[];
  nextSession: Session | null;
  isLoading: boolean;
  isRefreshing: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * Hook for fetching user's sessions/schedule
 *
 * @example
 * ```tsx
 * const { sessions, nextSession, refetch } = useSessionsQuery();
 *
 * // Get only upcoming
 * const { sessions } = useSessionsQuery({ status: 'upcoming' });
 * ```
 */
export function useSessionsQuery(options: UseSessionsOptions = {}): UseSessionsReturn {
  const { status, enabled = true } = options;
  const { logout, isAuthenticated } = useAuth();

  const query = useQuery({
    queryKey: queryKeys.userSessions,
    queryFn: async () => {
      const allSessions = await getSessions();

      // Sort by date (upcoming first)
      return allSessions.sort((a, b) => {
        const dateA = new Date(a.date).getTime() || 0;
        const dateB = new Date(b.date).getTime() || 0;
        return dateA - dateB;
      });
    },
    enabled: enabled && isAuthenticated,
    staleTime: STALE_TIMES.sessions,
    throwOnError: (error) => {
      if (error instanceof ApiClientError && error.isSessionExpired()) {
        logout();
        return false;
      }
      return false;
    },
  });

  const allSessions = query.data ?? [];

  // Filter by status if provided
  const filteredSessions = status
    ? allSessions.filter((s) => s.status === status)
    : allSessions;

  // Computed helpers
  const upcomingSessions = allSessions.filter((s) => s.status === 'upcoming');
  const completedSessions = allSessions.filter((s) => s.status === 'completed');
  const nextSession = upcomingSessions.length > 0 ? upcomingSessions[0] : null;

  return {
    sessions: filteredSessions,
    upcomingSessions,
    completedSessions,
    nextSession,
    isLoading: query.isLoading,
    isRefreshing: query.isRefetching && !query.isLoading,
    error: query.error?.message ?? null,
    refetch: async () => {
      await query.refetch();
    },
  };
}

// =============================================================================
// User Profile Hook
// =============================================================================

interface UseUserReturn {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * Hook for fetching current user profile
 *
 * @example
 * ```tsx
 * const { user, isLoading } = useUserQuery();
 * ```
 */
export function useUserQuery(): UseUserReturn {
  const { logout, isAuthenticated } = useAuth();

  const query = useQuery({
    queryKey: queryKeys.user,
    queryFn: getMe,
    enabled: isAuthenticated,
    staleTime: STALE_TIMES.user,
    throwOnError: (error) => {
      if (error instanceof ApiClientError && error.isSessionExpired()) {
        logout();
        return false;
      }
      return false;
    },
  });

  return {
    user: query.data ?? null,
    isLoading: query.isLoading,
    error: query.error?.message ?? null,
    refetch: async () => {
      await query.refetch();
    },
  };
}

// =============================================================================
// Home Screen Data Hook
// =============================================================================

/**
 * Combined hook for home screen that fetches all needed data
 *
 * @example
 * ```tsx
 * const { user, nextSession, stats, isLoading } = useHomeScreenData();
 * ```
 */
export function useHomeScreenData() {
  const userQuery = useUserQuery();
  const sessionsQuery = useSessionsQuery();

  const isLoading = userQuery.isLoading || sessionsQuery.isLoading;
  const error = userQuery.error || sessionsQuery.error;

  return {
    user: userQuery.user,
    nextSession: sessionsQuery.nextSession,
    upcomingSessions: sessionsQuery.upcomingSessions,
    completedSessions: sessionsQuery.completedSessions,
    stats: {
      upcomingCamps: sessionsQuery.upcomingSessions.length,
      completedCamps: sessionsQuery.completedSessions.length,
    },
    isLoading,
    error,
    refetch: async () => {
      await Promise.all([userQuery.refetch(), sessionsQuery.refetch()]);
    },
  };
}

// =============================================================================
// Prefetch Helper
// =============================================================================

/**
 * Prefetch user data and sessions (useful after login)
 */
export function usePrefetchUserData() {
  const queryClient = useQueryClient();

  return async () => {
    await Promise.all([
      queryClient.prefetchQuery({
        queryKey: queryKeys.user,
        queryFn: getMe,
        staleTime: STALE_TIMES.user,
      }),
      queryClient.prefetchQuery({
        queryKey: queryKeys.userSessions,
        queryFn: getSessions,
        staleTime: STALE_TIMES.sessions,
      }),
    ]);
  };
}

// =============================================================================
// Export
// =============================================================================

export { useSessionsQuery, useUserQuery, useHomeScreenData };
export default useSessionsQuery;
