/**
 * PTP Mobile App - Chat List Screen (Phase 2)
 *
 * Shows list of conversations:
 * - Support chat with PTP
 * - Trainer chats (after booking)
 * - Group chats (per camp, future)
 *
 * TODO Phase 2: Connect to Supabase/Firebase real-time backend
 */

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { LoadingScreen, EmptyState } from '../components';
import { colors, spacing, typography } from '../theme';
import { Conversation, ConversationType } from '../types/extended';

// =============================================================================
// Types
// =============================================================================

type ChatStackParamList = {
  ChatList: undefined;
  ChatScreen: { conversationId: string };
};

type Props = NativeStackScreenProps<ChatStackParamList, 'ChatList'>;

// =============================================================================
// Mock Data (Replace with real-time backend in Phase 2)
// =============================================================================

const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: 'support-1',
    type: 'parent-support',
    participantIds: [1, 0], // 0 = support
    participants: [
      { id: 0, name: 'PTP Support', role: 'support', isOnline: true },
    ],
    lastMessage: {
      text: 'Hi! How can we help you today?',
      senderId: 0,
      createdAt: new Date().toISOString(),
    },
    unreadCount: 0,
    isMuted: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// =============================================================================
// Component
// =============================================================================

const ChatListScreen: React.FC<Props> = ({ navigation }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // =============================================================================
  // Data Fetching (Replace with Supabase subscription in Phase 2)
  // =============================================================================

  useEffect(() => {
    loadConversations();
  }, []);

  const loadConversations = async () => {
    try {
      // TODO Phase 2: Replace with real-time subscription
      // const { data } = await supabase
      //   .from('conversations')
      //   .select('*, messages(text, sender_id, created_at)')
      //   .order('updated_at', { ascending: false });

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500));
      setConversations(MOCK_CONVERSATIONS);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    loadConversations();
  };

  // =============================================================================
  // Handlers
  // =============================================================================

  const handleConversationPress = (conversation: Conversation) => {
    navigation.navigate('ChatScreen', { conversationId: conversation.id });
  };

  // =============================================================================
  // Render Functions
  // =============================================================================

  const getConversationTitle = (conversation: Conversation): string => {
    switch (conversation.type) {
      case 'parent-support':
        return 'PTP Support';
      case 'parent-trainer':
        const trainer = conversation.participants?.find((p) => p.role === 'trainer');
        return trainer?.name || 'Your Trainer';
      case 'group':
        return 'Camp Group Chat';
      default:
        return 'Conversation';
    }
  };

  const getConversationIcon = (type: ConversationType): string => {
    switch (type) {
      case 'parent-support':
        return '💬';
      case 'parent-trainer':
        return '⚽';
      case 'group':
        return '👥';
      default:
        return '💬';
    }
  };

  const formatTime = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const renderConversationItem = ({ item }: { item: Conversation }) => (
    <TouchableOpacity
      style={styles.conversationItem}
      onPress={() => handleConversationPress(item)}
      activeOpacity={0.7}
    >
      {/* Avatar */}
      <View style={styles.avatarContainer}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{getConversationIcon(item.type)}</Text>
        </View>
        {item.participants?.[0]?.isOnline && (
          <View style={styles.onlineIndicator} />
        )}
      </View>

      {/* Content */}
      <View style={styles.conversationContent}>
        <View style={styles.conversationHeader}>
          <Text style={styles.conversationTitle} numberOfLines={1}>
            {getConversationTitle(item)}
          </Text>
          {item.lastMessage && (
            <Text style={styles.conversationTime}>
              {formatTime(item.lastMessage.createdAt)}
            </Text>
          )}
        </View>

        <View style={styles.conversationPreview}>
          <Text style={styles.previewText} numberOfLines={1}>
            {item.lastMessage?.text || 'No messages yet'}
          </Text>
          {item.unreadCount > 0 && (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadText}>
                {item.unreadCount > 99 ? '99+' : item.unreadCount}
              </Text>
            </View>
          )}
        </View>
      </View>

      {/* Chevron */}
      <Text style={styles.chevron}>›</Text>
    </TouchableOpacity>
  );

  // =============================================================================
  // Loading State
  // =============================================================================

  if (isLoading) {
    return <LoadingScreen message="Loading messages..." />;
  }

  // =============================================================================
  // Empty State
  // =============================================================================

  if (conversations.length === 0) {
    return (
      <EmptyState
        title="No Messages Yet"
        message="Start a conversation with PTP Support or book a training session to chat with your trainer."
        icon="💬"
      />
    );
  }

  // =============================================================================
  // Main Render
  // =============================================================================

  return (
    <SafeAreaView style={styles.container} edges={['left', 'right']}>
      <FlatList
        data={conversations}
        keyExtractor={(item) => item.id}
        renderItem={renderConversationItem}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
    </SafeAreaView>
  );
};

// =============================================================================
// Styles
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  listContent: {
    paddingVertical: spacing.md,
  },
  separator: {
    height: 1,
    backgroundColor: colors.border,
    marginLeft: 72 + spacing.md,
  },

  // Conversation Item
  conversationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },

  // Avatar
  avatarContainer: {
    position: 'relative',
    marginRight: spacing.md,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.offWhite,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 24,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#22C55E',
    borderWidth: 2,
    borderColor: colors.white,
  },

  // Content
  conversationContent: {
    flex: 1,
  },
  conversationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  conversationTitle: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.ink,
    flex: 1,
  },
  conversationTime: {
    fontSize: typography.sizes.xs,
    color: colors.gray,
    marginLeft: spacing.sm,
  },
  conversationPreview: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  previewText: {
    fontSize: typography.sizes.sm,
    color: colors.gray,
    flex: 1,
  },

  // Unread Badge
  unreadBadge: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xs,
    marginLeft: spacing.sm,
  },
  unreadText: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.bold,
    color: colors.white,
  },

  // Chevron
  chevron: {
    fontSize: 24,
    color: colors.border,
    marginLeft: spacing.sm,
  },
});

export default ChatListScreen;
