/**
 * PTP Mobile App - Home Screen
 *
 * Concierge-style dashboard with:
 * - Personalized greeting
 * - Next session card
 * - Quick access to messaging (Phase 2)
 * - Promotional banners
 * - Quick stats
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  RefreshControl,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useHomeScreenData } from '../hooks/useSessionsQuery';
import { useActivePromotions, useFeatureFlag } from '../hooks/useAppConfig';
import { Card, LoadingScreen } from '../components';
import { colors, spacing, typography } from '../theme';
import { Session } from '../types';
import { PromoBanner } from '../types/extended';

// =============================================================================
// Component
// =============================================================================

interface HomeScreenProps {
  navigation: any;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ navigation }) => {
  // Fetch all home screen data
  const { user, nextSession, stats, isLoading, error, refetch } = useHomeScreenData();

  // Get active promotions
  const promotions = useActivePromotions();

  // Check feature flags
  const isMessagingEnabled = useFeatureFlag('enableMessaging');

  // =============================================================================
  // Handlers
  // =============================================================================

  const handleRefresh = async () => {
    await refetch();
  };

  const handleViewSchedule = () => {
    navigation.navigate('ScheduleTab');
  };

  const handleViewCamps = () => {
    navigation.navigate('CampsTab');
  };

  const handleMessageSupport = () => {
    if (isMessagingEnabled) {
      // Navigate to support chat (Phase 2)
      navigation.navigate('ChatScreen', { type: 'support' });
    } else {
      // Fallback to email
      Linking.openURL('mailto:info@ptpsummercamps.com?subject=PTP Support Request');
    }
  };

  const handlePromoPress = (promo: PromoBanner) => {
    if (promo.ctaUrl) {
      Linking.openURL(promo.ctaUrl);
    }
  };

  // =============================================================================
  // Render Functions
  // =============================================================================

  const renderGreeting = () => {
    const hour = new Date().getHours();
    let greeting = 'Hello';
    if (hour < 12) greeting = 'Good morning';
    else if (hour < 17) greeting = 'Good afternoon';
    else greeting = 'Good evening';

    const firstName = user?.name?.split(' ')[0] || 'there';

    return (
      <View style={styles.greetingContainer}>
        <Text style={styles.greeting}>{greeting}, {firstName}!</Text>
        <Text style={styles.subGreeting}>
          {stats.upcomingCamps > 0
            ? `You have ${stats.upcomingCamps} upcoming ${stats.upcomingCamps === 1 ? 'session' : 'sessions'}`
            : 'Welcome to PTP Soccer Camps'}
        </Text>
      </View>
    );
  };

  const renderNextSession = () => {
    if (!nextSession) {
      return (
        <Card style={styles.nextSessionCard}>
          <Text style={styles.sectionTitle}>No Upcoming Sessions</Text>
          <Text style={styles.emptyText}>
            Ready to improve your game? Find a camp near you!
          </Text>
          <TouchableOpacity style={styles.ctaButton} onPress={handleViewCamps}>
            <Text style={styles.ctaButtonText}>Browse Camps</Text>
          </TouchableOpacity>
        </Card>
      );
    }

    return (
      <Card style={styles.nextSessionCard} onPress={handleViewSchedule}>
        <View style={styles.nextSessionHeader}>
          <Text style={styles.sectionTitle}>Next Session</Text>
          <Text style={styles.sessionBadge}>{nextSession.type.toUpperCase()}</Text>
        </View>

        <Text style={styles.sessionName}>{nextSession.name}</Text>

        <View style={styles.sessionDetails}>
          <View style={styles.sessionDetailRow}>
            <Text style={styles.sessionIcon}>📅</Text>
            <Text style={styles.sessionDetailText}>{nextSession.date}</Text>
          </View>

          {nextSession.time && (
            <View style={styles.sessionDetailRow}>
              <Text style={styles.sessionIcon}>⏰</Text>
              <Text style={styles.sessionDetailText}>{nextSession.time}</Text>
            </View>
          )}

          <View style={styles.sessionDetailRow}>
            <Text style={styles.sessionIcon}>📍</Text>
            <Text style={styles.sessionDetailText}>{nextSession.location}</Text>
          </View>

          {nextSession.trainer_name && (
            <View style={styles.sessionDetailRow}>
              <Text style={styles.sessionIcon}>👤</Text>
              <Text style={styles.sessionDetailText}>{nextSession.trainer_name}</Text>
            </View>
          )}
        </View>

        <TouchableOpacity style={styles.viewDetailsButton} onPress={handleViewSchedule}>
          <Text style={styles.viewDetailsText}>View Full Schedule →</Text>
        </TouchableOpacity>
      </Card>
    );
  };

  const renderQuickActions = () => (
    <View style={styles.quickActionsContainer}>
      <TouchableOpacity style={styles.quickAction} onPress={handleViewCamps}>
        <View style={[styles.quickActionIcon, { backgroundColor: '#E8F5E9' }]}>
          <Text style={styles.quickActionEmoji}>⚽</Text>
        </View>
        <Text style={styles.quickActionText}>Find Camps</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.quickAction} onPress={handleViewSchedule}>
        <View style={[styles.quickActionIcon, { backgroundColor: '#E3F2FD' }]}>
          <Text style={styles.quickActionEmoji}>📅</Text>
        </View>
        <Text style={styles.quickActionText}>My Schedule</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.quickAction} onPress={handleMessageSupport}>
        <View style={[styles.quickActionIcon, { backgroundColor: '#FFF3E0' }]}>
          <Text style={styles.quickActionEmoji}>💬</Text>
        </View>
        <Text style={styles.quickActionText}>Get Help</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.quickAction}
        onPress={() => navigation.navigate('TrainersTab')}
      >
        <View style={[styles.quickActionIcon, { backgroundColor: '#F3E5F5' }]}>
          <Text style={styles.quickActionEmoji}>🏅</Text>
        </View>
        <Text style={styles.quickActionText}>Trainers</Text>
      </TouchableOpacity>
    </View>
  );

  const renderPromotions = () => {
    if (promotions.length === 0) return null;

    return (
      <View style={styles.promotionsContainer}>
        {promotions.slice(0, 2).map((promo) => (
          <TouchableOpacity
            key={promo.id}
            style={[
              styles.promoCard,
              { backgroundColor: promo.backgroundColor || colors.primary },
            ]}
            onPress={() => handlePromoPress(promo)}
            activeOpacity={0.8}
          >
            <View style={styles.promoContent}>
              <Text style={styles.promoTitle}>{promo.title}</Text>
              {promo.body && (
                <Text style={styles.promoBody} numberOfLines={2}>
                  {promo.body}
                </Text>
              )}
              {promo.ctaText && (
                <Text style={styles.promoCta}>{promo.ctaText} →</Text>
              )}
            </View>
            {promo.imageUrl && (
              <Image
                source={{ uri: promo.imageUrl }}
                style={styles.promoImage}
                resizeMode="cover"
              />
            )}
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  const renderStats = () => {
    if (stats.completedCamps === 0 && stats.upcomingCamps === 0) return null;

    return (
      <View style={styles.statsContainer}>
        <Text style={styles.sectionTitle}>Your Progress</Text>
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.upcomingCamps}</Text>
            <Text style={styles.statLabel}>Upcoming</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.completedCamps}</Text>
            <Text style={styles.statLabel}>Completed</Text>
          </View>
        </View>
      </View>
    );
  };

  // =============================================================================
  // Loading State
  // =============================================================================

  if (isLoading) {
    return <LoadingScreen message="Loading..." />;
  }

  // =============================================================================
  // Main Render
  // =============================================================================

  return (
    <SafeAreaView style={styles.container} edges={['left', 'right']}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        }
      >
        {renderGreeting()}
        {renderNextSession()}
        {renderQuickActions()}
        {renderPromotions()}
        {renderStats()}
      </ScrollView>
    </SafeAreaView>
  );
};

// =============================================================================
// Styles
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.offWhite,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
    paddingBottom: spacing.xl * 2,
  },

  // Greeting
  greetingContainer: {
    marginBottom: spacing.xl,
  },
  greeting: {
    fontSize: 28,
    fontWeight: typography.weights.bold,
    color: colors.ink,
    marginBottom: spacing.xs,
  },
  subGreeting: {
    fontSize: typography.sizes.md,
    color: colors.gray,
  },

  // Next Session Card
  nextSessionCard: {
    marginBottom: spacing.lg,
  },
  nextSessionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.gray,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  sessionBadge: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.bold,
    color: colors.white,
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs / 2,
    borderRadius: 4,
    overflow: 'hidden',
  },
  sessionName: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.ink,
    marginBottom: spacing.md,
  },
  sessionDetails: {
    gap: spacing.xs,
  },
  sessionDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sessionIcon: {
    width: 24,
    fontSize: 14,
  },
  sessionDetailText: {
    fontSize: typography.sizes.sm,
    color: colors.gray,
    flex: 1,
  },
  viewDetailsButton: {
    marginTop: spacing.lg,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  viewDetailsText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.primary,
    textAlign: 'center',
  },
  emptyText: {
    fontSize: typography.sizes.md,
    color: colors.gray,
    marginBottom: spacing.lg,
    lineHeight: typography.sizes.md * typography.lineHeights.relaxed,
  },
  ctaButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: 8,
    alignItems: 'center',
  },
  ctaButtonText: {
    color: colors.white,
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
  },

  // Quick Actions
  quickActionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.xl,
  },
  quickAction: {
    alignItems: 'center',
    flex: 1,
  },
  quickActionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  quickActionEmoji: {
    fontSize: 24,
  },
  quickActionText: {
    fontSize: typography.sizes.xs,
    color: colors.gray,
    fontWeight: typography.weights.medium,
    textAlign: 'center',
  },

  // Promotions
  promotionsContainer: {
    marginBottom: spacing.xl,
    gap: spacing.md,
  },
  promoCard: {
    borderRadius: 12,
    overflow: 'hidden',
    flexDirection: 'row',
  },
  promoContent: {
    flex: 1,
    padding: spacing.lg,
  },
  promoTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.white,
    marginBottom: spacing.xs,
  },
  promoBody: {
    fontSize: typography.sizes.sm,
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: spacing.sm,
  },
  promoCta: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.white,
  },
  promoImage: {
    width: 100,
    height: '100%',
  },

  // Stats
  statsContainer: {
    marginBottom: spacing.lg,
  },
  statsRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: 12,
    padding: spacing.lg,
    alignItems: 'center',
    shadowColor: colors.ink,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statNumber: {
    fontSize: 32,
    fontWeight: typography.weights.bold,
    color: colors.primary,
    marginBottom: spacing.xs,
  },
  statLabel: {
    fontSize: typography.sizes.sm,
    color: colors.gray,
  },
});

export default HomeScreen;
