/**
 * PTP Mobile App - Chat Screen (Phase 2)
 *
 * Individual conversation view with:
 * - Real-time message updates
 * - Optimistic UI for sending
 * - Read receipts
 * - System messages
 *
 * TODO Phase 2: Connect to Supabase/Firebase real-time backend
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useAuth } from '../context/AuthContext';
import { colors, spacing, typography } from '../theme';
import { Message, Conversation } from '../types/extended';

// =============================================================================
// Types
// =============================================================================

type ChatStackParamList = {
  ChatList: undefined;
  ChatScreen: { conversationId: string; type?: 'support' | 'trainer' };
};

type Props = NativeStackScreenProps<ChatStackParamList, 'ChatScreen'>;

// =============================================================================
// Mock Data (Replace with real-time backend in Phase 2)
// =============================================================================

const MOCK_MESSAGES: Message[] = [
  {
    id: 'msg-1',
    conversationId: 'support-1',
    senderId: 0,
    text: 'Hi! Welcome to PTP Soccer Camps. How can we help you today?',
    seenBy: [1],
    isSystem: false,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'msg-2',
    conversationId: 'support-1',
    senderId: 1,
    text: 'Hi, I have a question about the summer camp schedule.',
    seenBy: [0, 1],
    isSystem: false,
    createdAt: new Date(Date.now() - 3500000).toISOString(),
  },
  {
    id: 'msg-3',
    conversationId: 'support-1',
    senderId: 0,
    text: "Of course! I'd be happy to help. Which location are you interested in?",
    seenBy: [1],
    isSystem: false,
    createdAt: new Date(Date.now() - 3400000).toISOString(),
  },
];

// =============================================================================
// Component
// =============================================================================

const ChatScreen: React.FC<Props> = ({ route, navigation }) => {
  const { conversationId, type } = route.params;
  const { user } = useAuth();
  const flatListRef = useRef<FlatList>(null);

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);

  const currentUserId = user?.id ?? 1;

  // =============================================================================
  // Data Fetching (Replace with Supabase subscription in Phase 2)
  // =============================================================================

  useEffect(() => {
    loadMessages();

    // TODO Phase 2: Set up real-time subscription
    // const subscription = supabase
    //   .channel(`conversation:${conversationId}`)
    //   .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, handleNewMessage)
    //   .subscribe();
    //
    // return () => {
    //   subscription.unsubscribe();
    // };
  }, [conversationId]);

  const loadMessages = async () => {
    try {
      // TODO Phase 2: Replace with real-time fetch
      // const { data } = await supabase
      //   .from('messages')
      //   .select('*')
      //   .eq('conversation_id', conversationId)
      //   .order('created_at', { ascending: true });

      await new Promise((resolve) => setTimeout(resolve, 300));
      setMessages(MOCK_MESSAGES);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // =============================================================================
  // Handlers
  // =============================================================================

  const handleSend = useCallback(async () => {
    if (!inputText.trim() || isSending) return;

    const messageText = inputText.trim();
    setInputText('');
    setIsSending(true);

    // Create optimistic message
    const optimisticMessage: Message = {
      id: `temp-${Date.now()}`,
      conversationId,
      senderId: currentUserId,
      text: messageText,
      seenBy: [currentUserId],
      isSystem: false,
      createdAt: new Date().toISOString(),
    };

    // Add optimistically
    setMessages((prev) => [...prev, optimisticMessage]);

    // Scroll to bottom
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);

    try {
      // TODO Phase 2: Send to real-time backend
      // const { data, error } = await supabase
      //   .from('messages')
      //   .insert({
      //     conversation_id: conversationId,
      //     sender_id: currentUserId,
      //     text: messageText,
      //   })
      //   .select()
      //   .single();
      //
      // if (error) throw error;
      //
      // // Replace optimistic message with real one
      // setMessages((prev) =>
      //   prev.map((msg) => (msg.id === optimisticMessage.id ? data : msg))
      // );

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500));

      // Simulate support reply
      if (type === 'support') {
        setTimeout(() => {
          const supportReply: Message = {
            id: `msg-${Date.now()}`,
            conversationId,
            senderId: 0,
            text: "Thanks for your message! A member of our team will respond shortly. Our typical response time is within a few hours during business hours.",
            seenBy: [],
            isSystem: false,
            createdAt: new Date().toISOString(),
          };
          setMessages((prev) => [...prev, supportReply]);
          flatListRef.current?.scrollToEnd({ animated: true });
        }, 2000);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      // Remove optimistic message on error
      setMessages((prev) => prev.filter((msg) => msg.id !== optimisticMessage.id));
      setInputText(messageText); // Restore input
    } finally {
      setIsSending(false);
    }
  }, [inputText, isSending, conversationId, currentUserId, type]);

  // =============================================================================
  // Render Functions
  // =============================================================================

  const formatMessageTime = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMessage = ({ item, index }: { item: Message; index: number }) => {
    const isOwnMessage = item.senderId === currentUserId;
    const isSystem = item.isSystem;

    // Check if we should show timestamp (first message or 30+ min gap)
    const prevMessage = index > 0 ? messages[index - 1] : null;
    const showTimestamp =
      !prevMessage ||
      new Date(item.createdAt).getTime() - new Date(prevMessage.createdAt).getTime() > 1800000;

    if (isSystem) {
      return (
        <View style={styles.systemMessageContainer}>
          {showTimestamp && (
            <Text style={styles.timestampText}>
              {formatMessageTime(item.createdAt)}
            </Text>
          )}
          <View style={styles.systemMessage}>
            <Text style={styles.systemMessageText}>{item.text}</Text>
          </View>
        </View>
      );
    }

    return (
      <View>
        {showTimestamp && (
          <Text style={styles.timestampText}>
            {formatMessageTime(item.createdAt)}
          </Text>
        )}
        <View
          style={[
            styles.messageContainer,
            isOwnMessage ? styles.ownMessageContainer : styles.otherMessageContainer,
          ]}
        >
          <View
            style={[
              styles.messageBubble,
              isOwnMessage ? styles.ownMessageBubble : styles.otherMessageBubble,
            ]}
          >
            <Text
              style={[
                styles.messageText,
                isOwnMessage ? styles.ownMessageText : styles.otherMessageText,
              ]}
            >
              {item.text}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  const renderInputBar = () => (
    <View style={styles.inputContainer}>
      <TextInput
        style={styles.textInput}
        value={inputText}
        onChangeText={setInputText}
        placeholder="Type a message..."
        placeholderTextColor={colors.gray}
        multiline
        maxLength={1000}
        returnKeyType="default"
      />
      <TouchableOpacity
        style={[
          styles.sendButton,
          (!inputText.trim() || isSending) && styles.sendButtonDisabled,
        ]}
        onPress={handleSend}
        disabled={!inputText.trim() || isSending}
        activeOpacity={0.7}
      >
        {isSending ? (
          <ActivityIndicator size="small" color={colors.white} />
        ) : (
          <Text style={styles.sendButtonText}>Send</Text>
        )}
      </TouchableOpacity>
    </View>
  );

  // =============================================================================
  // Loading State
  // =============================================================================

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container} edges={['left', 'right', 'bottom']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  // =============================================================================
  // Main Render
  // =============================================================================

  return (
    <SafeAreaView style={styles.container} edges={['left', 'right', 'bottom']}>
      <KeyboardAvoidingView
        style={styles.keyboardAvoid}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessage}
          contentContainerStyle={styles.messagesList}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => {
            flatListRef.current?.scrollToEnd({ animated: false });
          }}
        />
        {renderInputBar()}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// =============================================================================
// Styles
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.offWhite,
  },
  keyboardAvoid: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Messages List
  messagesList: {
    padding: spacing.md,
    paddingBottom: spacing.lg,
  },

  // Timestamp
  timestampText: {
    fontSize: typography.sizes.xs,
    color: colors.gray,
    textAlign: 'center',
    marginVertical: spacing.md,
  },

  // Message Containers
  messageContainer: {
    marginBottom: spacing.sm,
  },
  ownMessageContainer: {
    alignItems: 'flex-end',
  },
  otherMessageContainer: {
    alignItems: 'flex-start',
  },

  // Message Bubbles
  messageBubble: {
    maxWidth: '80%',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: 16,
  },
  ownMessageBubble: {
    backgroundColor: colors.primary,
    borderBottomRightRadius: 4,
  },
  otherMessageBubble: {
    backgroundColor: colors.white,
    borderBottomLeftRadius: 4,
    shadowColor: colors.ink,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },

  // Message Text
  messageText: {
    fontSize: typography.sizes.md,
    lineHeight: typography.sizes.md * 1.4,
  },
  ownMessageText: {
    color: colors.white,
  },
  otherMessageText: {
    color: colors.ink,
  },

  // System Messages
  systemMessageContainer: {
    alignItems: 'center',
    marginVertical: spacing.sm,
  },
  systemMessage: {
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    borderRadius: 12,
  },
  systemMessageText: {
    fontSize: typography.sizes.sm,
    color: colors.gray,
    fontStyle: 'italic',
  },

  // Input Container
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: spacing.md,
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  textInput: {
    flex: 1,
    minHeight: 40,
    maxHeight: 120,
    backgroundColor: colors.offWhite,
    borderRadius: 20,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: typography.sizes.md,
    color: colors.ink,
    marginRight: spacing.sm,
  },
  sendButton: {
    backgroundColor: colors.primary,
    borderRadius: 20,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    minWidth: 70,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: colors.border,
  },
  sendButtonText: {
    color: colors.white,
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
  },
});

export default ChatScreen;
