/**
 * PTP Mobile App - Camps Screen (React Query Version)
 *
 * Features:
 * - React Query for automatic caching and background refresh
 * - Stale-while-revalidate behavior
 * - Pull to refresh
 * - State/category filtering
 * - "Updated X mins ago" indicator
 */

import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useCampsQuery } from '../hooks/useCampsQuery';
import { useAppConfig } from '../hooks/useAppConfig';
import { Card, Badge, LoadingScreen, ErrorState, EmptyState } from '../components';
import { colors, spacing, typography } from '../theme';
import { Camp, CampsStackParamList } from '../types';

type Props = NativeStackScreenProps<CampsStackParamList, 'Camps'>;

// =============================================================================
// Filter Options
// =============================================================================

const STATE_OPTIONS = [
  { value: '', label: 'All States' },
  { value: 'PA', label: 'Pennsylvania' },
  { value: 'NJ', label: 'New Jersey' },
  { value: 'DE', label: 'Delaware' },
  { value: 'MD', label: 'Maryland' },
  { value: 'NY', label: 'New York' },
];

const CATEGORY_OPTIONS = [
  { value: '', label: 'All' },
  { value: 'summer', label: 'Summer Camps' },
  { value: 'winter-clinics', label: 'Winter Clinics' },
];

// =============================================================================
// Component
// =============================================================================

const CampsScreen: React.FC<Props> = ({ navigation }) => {
  // Filter state
  const [stateFilter, setStateFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  // Feature flags
  const { features } = useAppConfig();

  // Fetch camps with React Query
  const {
    camps,
    isLoading,
    isRefreshing,
    error,
    refetch,
    isStale,
    dataUpdatedAt,
  } = useCampsQuery({
    filters: {
      state: stateFilter || undefined,
      category: categoryFilter || undefined,
    },
  });

  // Calculate "updated X mins ago"
  const updatedAgo = useMemo(() => {
    if (!dataUpdatedAt) return null;
    const mins = Math.floor((Date.now() - dataUpdatedAt) / 60000);
    if (mins < 1) return 'Updated just now';
    if (mins === 1) return 'Updated 1 min ago';
    return `Updated ${mins} mins ago`;
  }, [dataUpdatedAt]);

  // =============================================================================
  // Handlers
  // =============================================================================

  const handleCampPress = (camp: Camp) => {
    navigation.navigate('CampDetail', { camp });
  };

  const handleRefresh = async () => {
    await refetch();
  };

  // =============================================================================
  // Render Functions
  // =============================================================================

  const renderFilterChips = () => (
    <View style={styles.filterContainer}>
      {/* State Filter */}
      <View style={styles.filterRow}>
        {STATE_OPTIONS.slice(0, 4).map((option) => (
          <TouchableOpacity
            key={option.value}
            style={[
              styles.filterChip,
              stateFilter === option.value && styles.filterChipActive,
            ]}
            onPress={() => setStateFilter(option.value)}
          >
            <Text
              style={[
                styles.filterChipText,
                stateFilter === option.value && styles.filterChipTextActive,
              ]}
            >
              {option.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Category Filter */}
      <View style={styles.filterRow}>
        {CATEGORY_OPTIONS.map((option) => (
          <TouchableOpacity
            key={option.value}
            style={[
              styles.filterChip,
              categoryFilter === option.value && styles.filterChipActive,
            ]}
            onPress={() => setCategoryFilter(option.value)}
          >
            <Text
              style={[
                styles.filterChipText,
                categoryFilter === option.value && styles.filterChipTextActive,
              ]}
            >
              {option.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Updated indicator */}
      {updatedAgo && (
        <View style={styles.updatedRow}>
          <Text style={styles.updatedText}>
            {isStale ? '⚠️ ' : ''}
            {updatedAgo}
          </Text>
        </View>
      )}
    </View>
  );

  const renderCampCard = ({ item }: { item: Camp }) => (
    <Card style={styles.campCard} onPress={() => handleCampPress(item)}>
      {/* Camp Image */}
      {item.image ? (
        <Image
          source={{ uri: item.image }}
          style={styles.campImage}
          resizeMode="cover"
        />
      ) : (
        <View style={[styles.campImage, styles.campImagePlaceholder]}>
          <Text style={styles.campImagePlaceholderText}>PTP</Text>
        </View>
      )}

      {/* Camp Info */}
      <View style={styles.campInfo}>
        {/* Badges */}
        <View style={styles.badgeRow}>
          {item.bestseller && (
            <Badge label="Best Seller" variant="bestseller" style={styles.badge} />
          )}
          {item.almost_full && (
            <Badge label="Almost Full" variant="almostFull" style={styles.badge} />
          )}
        </View>

        {/* Name */}
        <Text style={styles.campName} numberOfLines={2}>
          {item.name}
        </Text>

        {/* Details */}
        <View style={styles.detailsRow}>
          <Text style={styles.detailIcon}>📅</Text>
          <Text style={styles.detailText}>{item.date}</Text>
        </View>

        {item.time && (
          <View style={styles.detailsRow}>
            <Text style={styles.detailIcon}>⏰</Text>
            <Text style={styles.detailText}>{item.time}</Text>
          </View>
        )}

        <View style={styles.detailsRow}>
          <Text style={styles.detailIcon}>📍</Text>
          <Text style={styles.detailText}>
            {item.location}
            {item.state ? `, ${item.state}` : ''}
          </Text>
        </View>

        {/* Price */}
        <View style={styles.priceRow}>
          <Text style={styles.price}>{item.price}</Text>
          <Text style={styles.viewDetails}>View Details →</Text>
        </View>
      </View>
    </Card>
  );

  const renderHeader = () => renderFilterChips();

  const renderEmpty = () => {
    if (isLoading) return null;

    return (
      <EmptyState
        title="No Camps Found"
        message={
          stateFilter || categoryFilter
            ? 'Try adjusting your filters'
            : 'Check back soon for upcoming camps and clinics!'
        }
        icon="⚽"
      />
    );
  };

  // =============================================================================
  // Loading State
  // =============================================================================

  if (isLoading && camps.length === 0) {
    return <LoadingScreen message="Loading camps..." />;
  }

  // =============================================================================
  // Error State
  // =============================================================================

  if (error && camps.length === 0) {
    return <ErrorState message={error} onRetry={handleRefresh} />;
  }

  // =============================================================================
  // Main Render
  // =============================================================================

  return (
    <SafeAreaView style={styles.container} edges={['left', 'right']}>
      <FlatList
        data={camps}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderCampCard}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
    </SafeAreaView>
  );
};

// =============================================================================
// Styles
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.offWhite,
  },
  listContent: {
    padding: spacing.lg,
    paddingBottom: spacing.xl * 2,
  },
  separator: {
    height: spacing.lg,
  },

  // Filters
  filterContainer: {
    marginBottom: spacing.lg,
  },
  filterRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  filterChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: 20,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
  },
  filterChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  filterChipText: {
    fontSize: typography.sizes.sm,
    color: colors.gray,
  },
  filterChipTextActive: {
    color: colors.white,
    fontWeight: typography.weights.semibold,
  },
  updatedRow: {
    marginTop: spacing.xs,
  },
  updatedText: {
    fontSize: typography.sizes.xs,
    color: colors.gray,
    fontStyle: 'italic',
  },

  // Camp Card
  campCard: {
    overflow: 'hidden',
    padding: 0,
  },
  campImage: {
    width: '100%',
    height: 160,
    backgroundColor: colors.border,
  },
  campImagePlaceholder: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.ink,
  },
  campImagePlaceholderText: {
    fontSize: 32,
    fontWeight: typography.weights.bold,
    color: colors.primary,
  },
  campInfo: {
    padding: spacing.lg,
  },

  // Badges
  badgeRow: {
    flexDirection: 'row',
    marginBottom: spacing.sm,
  },
  badge: {
    marginRight: spacing.sm,
  },

  // Camp Name
  campName: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.ink,
    marginBottom: spacing.md,
    lineHeight: typography.sizes.lg * typography.lineHeights.tight,
  },

  // Details
  detailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  detailIcon: {
    fontSize: 14,
    marginRight: spacing.sm,
    width: 20,
    textAlign: 'center',
  },
  detailText: {
    fontSize: typography.sizes.sm,
    color: colors.gray,
    flex: 1,
  },

  // Price Row
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.md,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  price: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.ink,
  },
  viewDetails: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.primary,
  },
});

export default CampsScreen;
