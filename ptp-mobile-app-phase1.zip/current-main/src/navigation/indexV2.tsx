/**
 * PTP Mobile App - Navigation Configuration (Phase 1+)
 *
 * Structure:
 * - RootNavigator: Version Check -> Onboarding -> Auth vs Main
 * - AuthStack: Login screen
 * - MainTabs: Home, Camps, Training, Schedule, Profile
 * - CampsStack: Camps list -> Camp detail
 * - TrainingStack: Trainers list -> Trainer detail
 * - ChatStack: Chat list -> Chat detail (Phase 2)
 */

import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text, View, StyleSheet } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { LoadingScreen } from '../components';
import { colors, typography } from '../theme';

// Screens
import LoginScreen from '../screens/LoginScreen';
import HomeScreen from '../screens/HomeScreen';
import CampsScreen from '../screens/CampsScreen';
import CampDetailScreen from '../screens/CampDetailScreen';
import TrainersScreen from '../screens/TrainersScreen';
import TrainerDetailScreen from '../screens/TrainerDetailScreen';
import ScheduleScreen from '../screens/ScheduleScreen';
import ProfileScreen from '../screens/ProfileScreen';
import OnboardingScreen, { checkOnboardingComplete } from '../screens/OnboardingScreen';

// Phase 2 Screens (placeholder imports - create these files)
// import ChatListScreen from '../screens/ChatListScreen';
// import ChatScreen from '../screens/ChatScreen';

// Components
import VersionGate from '../components/VersionGate';

// Types
import {
  RootStackParamList,
  AuthStackParamList,
  MainTabParamList,
  CampsStackParamList,
  TrainingStackParamList,
} from '../types';

// =============================================================================
// Extended Navigation Types
// =============================================================================

export type HomeStackParamList = {
  Home: undefined;
  ChatList: undefined;
  ChatScreen: { conversationId?: string; type?: 'support' | 'trainer' };
};

export type ChatStackParamList = {
  ChatList: undefined;
  ChatScreen: { conversationId: string };
};

// =============================================================================
// Stack Navigators
// =============================================================================

const RootStack = createNativeStackNavigator<RootStackParamList>();
const AuthStackNav = createNativeStackNavigator<AuthStackParamList>();
const MainTab = createBottomTabNavigator<MainTabParamList>();
const CampsStackNav = createNativeStackNavigator<CampsStackParamList>();
const TrainingStackNav = createNativeStackNavigator<TrainingStackParamList>();
const HomeStackNav = createNativeStackNavigator<HomeStackParamList>();

// =============================================================================
// Tab Icon Component
// =============================================================================

interface TabIconProps {
  label: string;
  focused: boolean;
  badge?: number;
}

const TabIcon: React.FC<TabIconProps> = ({ label, focused, badge }) => {
  const getIcon = (): string => {
    switch (label) {
      case 'Home':
        return '🏠';
      case 'Camps':
        return '⚽';
      case 'Training':
        return '🏃';
      case 'Schedule':
        return '📅';
      case 'Profile':
        return '👤';
      case 'Messages':
        return '💬';
      default:
        return '●';
    }
  };

  return (
    <View style={styles.tabIconContainer}>
      <Text style={[styles.tabIcon, focused && styles.tabIconFocused]}>
        {getIcon()}
      </Text>
      {badge && badge > 0 && (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{badge > 99 ? '99+' : badge}</Text>
        </View>
      )}
    </View>
  );
};

// =============================================================================
// Auth Stack (Unauthenticated users)
// =============================================================================

const AuthStack: React.FC = () => {
  return (
    <AuthStackNav.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <AuthStackNav.Screen name="Login" component={LoginScreen} />
    </AuthStackNav.Navigator>
  );
};

// =============================================================================
// Home Stack (includes chat navigation)
// =============================================================================

const HomeStack: React.FC = () => {
  return (
    <HomeStackNav.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.white,
        },
        headerTintColor: colors.ink,
        headerTitleStyle: {
          fontWeight: typography.weights.semibold,
        },
        headerShadowVisible: false,
        headerBackTitleVisible: false,
      }}
    >
      <HomeStackNav.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: 'PTP Soccer',
          headerLargeTitle: false,
        }}
      />
      {/* Phase 2: Uncomment when chat screens are ready
      <HomeStackNav.Screen
        name="ChatList"
        component={ChatListScreen}
        options={{
          title: 'Messages',
        }}
      />
      <HomeStackNav.Screen
        name="ChatScreen"
        component={ChatScreen}
        options={{
          title: 'Chat',
        }}
      />
      */}
    </HomeStackNav.Navigator>
  );
};

// =============================================================================
// Camps Stack
// =============================================================================

const CampsStack: React.FC = () => {
  return (
    <CampsStackNav.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.white,
        },
        headerTintColor: colors.ink,
        headerTitleStyle: {
          fontWeight: typography.weights.semibold,
        },
        headerShadowVisible: false,
        headerBackTitleVisible: false,
      }}
    >
      <CampsStackNav.Screen
        name="Camps"
        component={CampsScreen}
        options={{
          title: 'Camps & Clinics',
        }}
      />
      <CampsStackNav.Screen
        name="CampDetail"
        component={CampDetailScreen}
        options={{
          title: 'Camp Details',
        }}
      />
    </CampsStackNav.Navigator>
  );
};

// =============================================================================
// Training Stack
// =============================================================================

const TrainingStack: React.FC = () => {
  return (
    <TrainingStackNav.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.white,
        },
        headerTintColor: colors.ink,
        headerTitleStyle: {
          fontWeight: typography.weights.semibold,
        },
        headerShadowVisible: false,
        headerBackTitleVisible: false,
      }}
    >
      <TrainingStackNav.Screen
        name="Trainers"
        component={TrainersScreen}
        options={{
          title: 'Private Training',
        }}
      />
      <TrainingStackNav.Screen
        name="TrainerDetail"
        component={TrainerDetailScreen}
        options={{
          title: 'Trainer Profile',
        }}
      />
    </TrainingStackNav.Navigator>
  );
};

// =============================================================================
// Main Tabs (Authenticated users)
// =============================================================================

const MainTabs: React.FC = () => {
  // TODO: Get unread message count from chat context (Phase 2)
  const unreadMessages = 0;

  return (
    <MainTab.Navigator
      screenOptions={{
        tabBarStyle: {
          backgroundColor: colors.white,
          borderTopColor: colors.border,
          paddingBottom: 8,
          paddingTop: 8,
          height: 60,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.gray,
        tabBarLabelStyle: {
          fontSize: typography.sizes.xs,
          fontWeight: typography.weights.medium,
        },
        headerShown: false,
      }}
    >
      {/* Home Tab - New default landing */}
      <MainTab.Screen
        name="HomeTab"
        component={HomeStack}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ focused }) => (
            <TabIcon label="Home" focused={focused} />
          ),
        }}
      />

      {/* Camps Tab */}
      <MainTab.Screen
        name="CampsTab"
        component={CampsStack}
        options={{
          tabBarLabel: 'Camps',
          tabBarIcon: ({ focused }) => (
            <TabIcon label="Camps" focused={focused} />
          ),
        }}
      />

      {/* Training Tab */}
      <MainTab.Screen
        name="TrainingTab"
        component={TrainingStack}
        options={{
          tabBarLabel: 'Training',
          tabBarIcon: ({ focused }) => (
            <TabIcon label="Training" focused={focused} />
          ),
        }}
      />

      {/* Schedule Tab */}
      <MainTab.Screen
        name="ScheduleTab"
        component={ScheduleScreen}
        options={{
          tabBarLabel: 'Schedule',
          tabBarIcon: ({ focused }) => (
            <TabIcon label="Schedule" focused={focused} />
          ),
          headerShown: true,
          headerTitle: 'My Schedule',
          headerStyle: {
            backgroundColor: colors.white,
          },
          headerTintColor: colors.ink,
          headerTitleStyle: {
            fontWeight: typography.weights.semibold,
          },
          headerShadowVisible: false,
        }}
      />

      {/* Profile Tab */}
      <MainTab.Screen
        name="ProfileTab"
        component={ProfileScreen}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ focused }) => (
            <TabIcon label="Profile" focused={focused} />
          ),
          headerShown: true,
          headerTitle: 'Profile',
          headerStyle: {
            backgroundColor: colors.white,
          },
          headerTintColor: colors.ink,
          headerTitleStyle: {
            fontWeight: typography.weights.semibold,
          },
          headerShadowVisible: false,
        }}
      />
    </MainTab.Navigator>
  );
};

// =============================================================================
// Root Navigator
// =============================================================================

const RootNavigator: React.FC = () => {
  const { user, isInitialized, isGuest } = useAuth();
  const [showOnboarding, setShowOnboarding] = useState<boolean | null>(null);

  // Check if onboarding has been completed
  useEffect(() => {
    const checkOnboarding = async () => {
      const isComplete = await checkOnboardingComplete();
      setShowOnboarding(!isComplete);
    };
    checkOnboarding();
  }, []);

  // Show loading screen while checking auth and onboarding state
  if (!isInitialized || showOnboarding === null) {
    return <LoadingScreen message="Loading..." />;
  }

  // Show onboarding if not completed
  if (showOnboarding) {
    return <OnboardingScreen onComplete={() => setShowOnboarding(false)} />;
  }

  return (
    <RootStack.Navigator screenOptions={{ headerShown: false }}>
      {user || isGuest ? (
        <RootStack.Screen name="Main" component={MainTabs} />
      ) : (
        <RootStack.Screen name="Auth" component={AuthStack} />
      )}
    </RootStack.Navigator>
  );
};

// =============================================================================
// App Navigation Container with Version Gate
// =============================================================================

export const AppNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <VersionGate>
        <RootNavigator />
      </VersionGate>
    </NavigationContainer>
  );
};

// =============================================================================
// Styles
// =============================================================================

const styles = StyleSheet.create({
  tabIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  tabIcon: {
    fontSize: 20,
    color: colors.gray,
  },
  tabIconFocused: {
    color: colors.primary,
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -10,
    backgroundColor: colors.error || '#EF4444',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: colors.white,
    fontSize: 10,
    fontWeight: typography.weights.bold,
  },
});

export default AppNavigator;
