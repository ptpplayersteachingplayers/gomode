/**
 * PTP Mobile App - Promotional Banner Component
 *
 * Displays promotional banners from the app config.
 * Can be used on home screen, camp list, or as interstitials.
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Linking,
  Dimensions,
} from 'react-native';
import { colors, spacing, typography } from '../theme';
import { PromoBanner as PromoBannerType } from '../types/extended';

// =============================================================================
// Props
// =============================================================================

interface PromoBannerProps {
  promotion: PromoBannerType;
  variant?: 'card' | 'banner' | 'compact';
  onPress?: () => void;
}

// =============================================================================
// Component
// =============================================================================

const PromoBanner: React.FC<PromoBannerProps> = ({
  promotion,
  variant = 'card',
  onPress,
}) => {
  const handlePress = () => {
    if (onPress) {
      onPress();
    } else if (promotion.ctaUrl) {
      Linking.openURL(promotion.ctaUrl);
    }
  };

  const backgroundColor = promotion.backgroundColor || colors.primary;

  // =============================================================================
  // Compact Variant
  // =============================================================================

  if (variant === 'compact') {
    return (
      <TouchableOpacity
        style={[styles.compactContainer, { backgroundColor }]}
        onPress={handlePress}
        activeOpacity={0.8}
      >
        <Text style={styles.compactTitle} numberOfLines={1}>
          {promotion.title}
        </Text>
        {promotion.ctaText && (
          <Text style={styles.compactCta}>{promotion.ctaText} →</Text>
        )}
      </TouchableOpacity>
    );
  }

  // =============================================================================
  // Banner Variant (Full width)
  // =============================================================================

  if (variant === 'banner') {
    return (
      <TouchableOpacity
        style={[styles.bannerContainer, { backgroundColor }]}
        onPress={handlePress}
        activeOpacity={0.8}
      >
        {promotion.imageUrl && (
          <Image
            source={{ uri: promotion.imageUrl }}
            style={styles.bannerImage}
            resizeMode="cover"
          />
        )}
        <View style={styles.bannerContent}>
          <Text style={styles.bannerTitle}>{promotion.title}</Text>
          {promotion.body && (
            <Text style={styles.bannerBody} numberOfLines={2}>
              {promotion.body}
            </Text>
          )}
          {promotion.ctaText && (
            <View style={styles.bannerCtaContainer}>
              <Text style={styles.bannerCta}>{promotion.ctaText} →</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    );
  }

  // =============================================================================
  // Card Variant (Default)
  // =============================================================================

  return (
    <TouchableOpacity
      style={[styles.cardContainer, { backgroundColor }]}
      onPress={handlePress}
      activeOpacity={0.8}
    >
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{promotion.title}</Text>
        {promotion.body && (
          <Text style={styles.cardBody} numberOfLines={2}>
            {promotion.body}
          </Text>
        )}
        {promotion.ctaText && (
          <Text style={styles.cardCta}>{promotion.ctaText} →</Text>
        )}
      </View>
      {promotion.imageUrl && (
        <Image
          source={{ uri: promotion.imageUrl }}
          style={styles.cardImage}
          resizeMode="cover"
        />
      )}
    </TouchableOpacity>
  );
};

// =============================================================================
// Styles
// =============================================================================

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const styles = StyleSheet.create({
  // Card Variant
  cardContainer: {
    borderRadius: 12,
    overflow: 'hidden',
    flexDirection: 'row',
    shadowColor: colors.ink,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  cardContent: {
    flex: 1,
    padding: spacing.lg,
    justifyContent: 'center',
  },
  cardTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.white,
    marginBottom: spacing.xs,
  },
  cardBody: {
    fontSize: typography.sizes.sm,
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: spacing.sm,
    lineHeight: typography.sizes.sm * 1.4,
  },
  cardCta: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.white,
  },
  cardImage: {
    width: 100,
    height: '100%',
    minHeight: 100,
  },

  // Banner Variant
  bannerContainer: {
    width: SCREEN_WIDTH,
    minHeight: 140,
    flexDirection: 'row',
  },
  bannerImage: {
    width: 120,
    height: '100%',
  },
  bannerContent: {
    flex: 1,
    padding: spacing.lg,
    justifyContent: 'center',
  },
  bannerTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.white,
    marginBottom: spacing.xs,
  },
  bannerBody: {
    fontSize: typography.sizes.md,
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: spacing.md,
    lineHeight: typography.sizes.md * 1.4,
  },
  bannerCtaContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignSelf: 'flex-start',
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    borderRadius: 20,
  },
  bannerCta: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.white,
  },

  // Compact Variant
  compactContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: 8,
  },
  compactTitle: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.white,
    flex: 1,
  },
  compactCta: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.white,
    marginLeft: spacing.sm,
  },
});

export default PromoBanner;
