/**
 * PTP Mobile App - Version Gate Component
 *
 * Checks app version against required minimum and shows
 * update prompt if needed. Blocks app access for force updates.
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  Image,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useVersionCheck } from '../hooks/useAppConfig';
import { colors, spacing, typography } from '../theme';

// =============================================================================
// Props
// =============================================================================

interface VersionGateProps {
  children: React.ReactNode;
}

// =============================================================================
// Component
// =============================================================================

/**
 * VersionGate wraps the app and checks version requirements.
 *
 * - Force update: Blocks the app entirely until updated
 * - Optional update: Shows dismissible modal
 */
const VersionGate: React.FC<VersionGateProps> = ({ children }) => {
  const {
    needsUpdate,
    isForceUpdate,
    hasOptionalUpdate,
    currentVersion,
    latestVersion,
    openStore,
  } = useVersionCheck();

  const [dismissed, setDismissed] = React.useState(false);

  // Don't show optional update if dismissed
  const showModal = isForceUpdate || (hasOptionalUpdate && !dismissed);

  if (!showModal) {
    return <>{children}</>;
  }

  return (
    <>
      {/* Show app content behind modal for optional updates */}
      {!isForceUpdate && children}

      <Modal
        visible={showModal}
        animationType="fade"
        transparent={!isForceUpdate}
        statusBarTranslucent
      >
        <SafeAreaView style={[
          styles.container,
          !isForceUpdate && styles.containerOverlay,
        ]}>
          <View style={[
            styles.content,
            !isForceUpdate && styles.contentModal,
          ]}>
            {/* Icon */}
            <View style={styles.iconContainer}>
              <Text style={styles.icon}>⬆️</Text>
            </View>

            {/* Title */}
            <Text style={styles.title}>
              {isForceUpdate ? 'Update Required' : 'Update Available'}
            </Text>

            {/* Message */}
            <Text style={styles.message}>
              {isForceUpdate
                ? `A new version of PTP Soccer is required to continue. Please update to version ${latestVersion} to access the latest features and improvements.`
                : `A new version (${latestVersion}) is available! Update now to get the latest features and improvements.`}
            </Text>

            {/* Version info */}
            <Text style={styles.versionInfo}>
              Current version: {currentVersion}
            </Text>

            {/* Buttons */}
            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.updateButton}
                onPress={openStore}
                activeOpacity={0.8}
              >
                <Text style={styles.updateButtonText}>Update Now</Text>
              </TouchableOpacity>

              {!isForceUpdate && (
                <TouchableOpacity
                  style={styles.laterButton}
                  onPress={() => setDismissed(true)}
                  activeOpacity={0.7}
                >
                  <Text style={styles.laterButtonText}>Maybe Later</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </>
  );
};

// =============================================================================
// Styles
// =============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
  },
  containerOverlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  content: {
    alignItems: 'center',
    maxWidth: 400,
  },
  contentModal: {
    backgroundColor: colors.white,
    borderRadius: 16,
    padding: spacing.xl,
    marginHorizontal: spacing.lg,
    shadowColor: colors.ink,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.primary + '15',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xl,
  },
  icon: {
    fontSize: 40,
  },
  title: {
    fontSize: typography.sizes.xxl || 24,
    fontWeight: typography.weights.bold,
    color: colors.ink,
    textAlign: 'center',
    marginBottom: spacing.md,
  },
  message: {
    fontSize: typography.sizes.md,
    color: colors.gray,
    textAlign: 'center',
    lineHeight: typography.sizes.md * (typography.lineHeights?.relaxed || 1.6),
    marginBottom: spacing.md,
  },
  versionInfo: {
    fontSize: typography.sizes.sm,
    color: colors.gray,
    marginBottom: spacing.xl,
  },
  buttonContainer: {
    width: '100%',
    gap: spacing.md,
  },
  updateButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: 12,
    alignItems: 'center',
    width: '100%',
  },
  updateButtonText: {
    color: colors.white,
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
  },
  laterButton: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  laterButtonText: {
    color: colors.gray,
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
  },
});

export default VersionGate;
