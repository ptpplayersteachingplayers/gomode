/**
 * PTP Mobile App - Query Provider
 *
 * Provides React Query context to the app with:
 * - QueryClientProvider setup
 * - App state focus handling for mobile
 * - Online state management
 */

import React, { useEffect } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import {
  QueryClientProvider,
  focusManager,
  onlineManager,
} from '@tanstack/react-query';
import NetInfo from '@react-native-community/netinfo';
import { queryClient } from './queryClient';

// =============================================================================
// Mobile Focus Management
// =============================================================================

/**
 * Set up app state listener for refetch on focus
 * React Query's built-in focus management doesn't work on mobile,
 * so we need to manually connect it to AppState
 */
function useAppStateFocus() {
  useEffect(() => {
    const subscription = AppState.addEventListener(
      'change',
      (status: AppStateStatus) => {
        focusManager.setFocused(status === 'active');
      }
    );

    return () => subscription.remove();
  }, []);
}

// =============================================================================
// Online State Management
// =============================================================================

/**
 * Set up network state listener
 * React Query needs to know when we're online/offline to manage retries
 */
function useOnlineManager() {
  useEffect(() => {
    return NetInfo.addEventListener((state) => {
      onlineManager.setOnline(
        state.isConnected != null &&
          state.isConnected &&
          Boolean(state.isInternetReachable)
      );
    });
  }, []);
}

// =============================================================================
// Provider Component
// =============================================================================

interface QueryProviderProps {
  children: React.ReactNode;
}

/**
 * QueryProvider wraps the app with React Query context
 *
 * @example
 * ```tsx
 * <QueryProvider>
 *   <App />
 * </QueryProvider>
 * ```
 */
export function QueryProvider({ children }: QueryProviderProps) {
  // Set up mobile-specific managers
  useAppStateFocus();
  useOnlineManager();

  return (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  );
}

export default QueryProvider;
