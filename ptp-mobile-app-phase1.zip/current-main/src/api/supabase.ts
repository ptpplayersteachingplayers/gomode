/**
 * PTP Mobile App - Supabase Client Configuration (Phase 2)
 *
 * Real-time backend for messaging and live updates.
 *
 * Setup Instructions:
 * 1. Create a Supabase project at https://supabase.com
 * 2. Copy your project URL and anon key
 * 3. Add to your .env file:
 *    EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
 *    EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
 * 4. Run the SQL migrations in /supabase/migrations/
 */

import { createClient, SupabaseClient, RealtimeChannel } from '@supabase/supabase-js';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

// =============================================================================
// Configuration
// =============================================================================

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

// Check if Supabase is configured
export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

// =============================================================================
// Custom Storage (SecureStore for mobile)
// =============================================================================

const ExpoSecureStoreAdapter = {
  getItem: async (key: string): Promise<string | null> => {
    try {
      return await SecureStore.getItemAsync(key);
    } catch (error) {
      console.warn('SecureStore getItem error:', error);
      return null;
    }
  },
  setItem: async (key: string, value: string): Promise<void> => {
    try {
      await SecureStore.setItemAsync(key, value);
    } catch (error) {
      console.warn('SecureStore setItem error:', error);
    }
  },
  removeItem: async (key: string): Promise<void> => {
    try {
      await SecureStore.deleteItemAsync(key);
    } catch (error) {
      console.warn('SecureStore removeItem error:', error);
    }
  },
};

// =============================================================================
// Supabase Client
// =============================================================================

let supabaseInstance: SupabaseClient | null = null;

/**
 * Get the Supabase client instance
 *
 * @example
 * ```tsx
 * import { getSupabase } from '../api/supabase';
 *
 * const supabase = getSupabase();
 * const { data } = await supabase.from('messages').select('*');
 * ```
 */
export function getSupabase(): SupabaseClient {
  if (!isSupabaseConfigured) {
    throw new Error(
      'Supabase is not configured. Add EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY to your .env file.'
    );
  }

  if (!supabaseInstance) {
    supabaseInstance = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        storage: ExpoSecureStoreAdapter,
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: false,
      },
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });
  }

  return supabaseInstance;
}

// =============================================================================
// Database Types (generated from Supabase schema)
// =============================================================================

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: number;
          wp_user_id: number;
          email: string;
          name: string;
          role: 'parent' | 'trainer' | 'admin';
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['users']['Row'], 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['users']['Insert']>;
      };
      conversations: {
        Row: {
          id: string;
          type: 'parent-support' | 'parent-trainer' | 'group';
          participant_ids: number[];
          camp_id: number | null;
          booking_id: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['conversations']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['conversations']['Insert']>;
      };
      messages: {
        Row: {
          id: string;
          conversation_id: string;
          sender_id: number;
          text: string;
          seen_by: number[];
          is_system: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['messages']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['messages']['Insert']>;
      };
    };
  };
}

// =============================================================================
// Real-time Subscriptions
// =============================================================================

type MessageCallback = (message: Database['public']['Tables']['messages']['Row']) => void;
type ConversationCallback = (conversation: Database['public']['Tables']['conversations']['Row']) => void;

/**
 * Subscribe to new messages in a conversation
 *
 * @example
 * ```tsx
 * const unsubscribe = subscribeToMessages(conversationId, (message) => {
 *   setMessages(prev => [...prev, message]);
 * });
 *
 * // Later...
 * unsubscribe();
 * ```
 */
export function subscribeToMessages(
  conversationId: string,
  callback: MessageCallback
): () => void {
  if (!isSupabaseConfigured) {
    console.warn('Supabase not configured, skipping subscription');
    return () => {};
  }

  const supabase = getSupabase();

  const channel = supabase
    .channel(`messages:${conversationId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload) => {
        callback(payload.new as Database['public']['Tables']['messages']['Row']);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}

/**
 * Subscribe to conversation updates (for the chat list)
 *
 * @example
 * ```tsx
 * const unsubscribe = subscribeToConversations(userId, (conversation) => {
 *   // Update conversation in list
 * });
 * ```
 */
export function subscribeToConversations(
  userId: number,
  callback: ConversationCallback
): () => void {
  if (!isSupabaseConfigured) {
    console.warn('Supabase not configured, skipping subscription');
    return () => {};
  }

  const supabase = getSupabase();

  const channel = supabase
    .channel(`conversations:user:${userId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'conversations',
        filter: `participant_ids=cs.{${userId}}`,
      },
      (payload) => {
        callback(payload.new as Database['public']['Tables']['conversations']['Row']);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}

// =============================================================================
// Message Operations
// =============================================================================

/**
 * Send a message to a conversation
 */
export async function sendMessage(
  conversationId: string,
  senderId: number,
  text: string
): Promise<Database['public']['Tables']['messages']['Row']> {
  const supabase = getSupabase();

  const { data, error } = await supabase
    .from('messages')
    .insert({
      conversation_id: conversationId,
      sender_id: senderId,
      text,
      seen_by: [senderId],
      is_system: false,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

/**
 * Mark messages as seen
 */
export async function markMessagesSeen(
  conversationId: string,
  userId: number,
  messageIds: string[]
): Promise<void> {
  const supabase = getSupabase();

  // Update seen_by array for each message
  const { error } = await supabase.rpc('mark_messages_seen', {
    p_message_ids: messageIds,
    p_user_id: userId,
  });

  if (error) throw error;
}

/**
 * Get messages for a conversation
 */
export async function getMessages(
  conversationId: string,
  limit = 50,
  before?: string
): Promise<Database['public']['Tables']['messages']['Row'][]> {
  const supabase = getSupabase();

  let query = supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true })
    .limit(limit);

  if (before) {
    query = query.lt('created_at', before);
  }

  const { data, error } = await query;

  if (error) throw error;
  return data;
}

// =============================================================================
// Conversation Operations
// =============================================================================

/**
 * Get user's conversations
 */
export async function getConversations(
  userId: number
): Promise<Database['public']['Tables']['conversations']['Row'][]> {
  const supabase = getSupabase();

  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .contains('participant_ids', [userId])
    .order('updated_at', { ascending: false });

  if (error) throw error;
  return data;
}

/**
 * Get or create a support conversation
 */
export async function getOrCreateSupportConversation(
  userId: number
): Promise<Database['public']['Tables']['conversations']['Row']> {
  const supabase = getSupabase();

  // Try to find existing support conversation
  const { data: existing } = await supabase
    .from('conversations')
    .select('*')
    .eq('type', 'parent-support')
    .contains('participant_ids', [userId])
    .single();

  if (existing) return existing;

  // Create new support conversation
  const { data: created, error } = await supabase
    .from('conversations')
    .insert({
      type: 'parent-support',
      participant_ids: [userId, 0], // 0 = support
    })
    .select()
    .single();

  if (error) throw error;
  return created;
}

// =============================================================================
// User Sync
// =============================================================================

/**
 * Sync WordPress user to Supabase
 * Called after login or when user data changes
 */
export async function syncUser(wpUser: {
  id: number;
  email: string;
  name: string;
  role: string;
}): Promise<void> {
  if (!isSupabaseConfigured) return;

  const supabase = getSupabase();

  const { error } = await supabase.from('users').upsert(
    {
      wp_user_id: wpUser.id,
      email: wpUser.email,
      name: wpUser.name,
      role: wpUser.role === 'administrator' ? 'admin' : 'parent',
    },
    {
      onConflict: 'wp_user_id',
    }
  );

  if (error) {
    console.error('Error syncing user to Supabase:', error);
  }
}

// =============================================================================
// Export
// =============================================================================

export default getSupabase;
