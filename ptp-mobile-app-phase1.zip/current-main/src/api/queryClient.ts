/**
 * PTP Mobile App - React Query Configuration
 *
 * Centralized React Query setup with:
 * - Default stale times optimized for PTP data patterns
 * - Retry configuration
 * - Global error handling
 * - App focus refetch behavior
 */

import { QueryClient } from '@tanstack/react-query';
import { ApiClientError } from './client';

// =============================================================================
// Stale Time Configuration (how long data is considered fresh)
// =============================================================================

export const STALE_TIMES = {
  // App config rarely changes - check every 30 minutes
  appConfig: 30 * 60 * 1000,

  // Camps change occasionally - 5 minute freshness
  camps: 5 * 60 * 1000,

  // Trainers change rarely - 10 minute freshness
  trainers: 10 * 60 * 1000,

  // User sessions need more frequent updates - 1 minute
  sessions: 60 * 1000,

  // User profile - 5 minutes
  user: 5 * 60 * 1000,

  // Chat/messages - real-time, always refetch
  messages: 0,

  // Conversations list - 30 seconds
  conversations: 30 * 1000,
} as const;

// =============================================================================
// Cache Time Configuration (how long inactive data stays in cache)
// =============================================================================

export const CACHE_TIMES = {
  default: 10 * 60 * 1000, // 10 minutes
  camps: 30 * 60 * 1000, // 30 minutes
  trainers: 60 * 60 * 1000, // 1 hour
  user: 60 * 60 * 1000, // 1 hour
} as const;

// =============================================================================
// Query Client Instance
// =============================================================================

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Don't refetch on window focus by default (mobile app handles this differently)
      refetchOnWindowFocus: false,

      // Refetch on reconnect
      refetchOnReconnect: true,

      // Retry failed requests up to 2 times
      retry: (failureCount, error) => {
        // Don't retry on auth errors
        if (error instanceof ApiClientError) {
          if (error.isSessionExpired() || error.status === 403) {
            return false;
          }
        }
        return failureCount < 2;
      },

      // Default stale time
      staleTime: STALE_TIMES.camps,

      // Default cache time
      gcTime: CACHE_TIMES.default,
    },
    mutations: {
      // Retry mutations once on network errors only
      retry: (failureCount, error) => {
        if (error instanceof ApiClientError && error.isNetworkError()) {
          return failureCount < 1;
        }
        return false;
      },
    },
  },
});

// =============================================================================
// Query Keys - Centralized key factory for type safety
// =============================================================================

export const queryKeys = {
  // App config
  appConfig: ['appConfig'] as const,

  // User
  user: ['user'] as const,
  userSessions: ['user', 'sessions'] as const,

  // Camps
  camps: {
    all: ['camps'] as const,
    list: (filters?: CampFilters) => ['camps', 'list', filters] as const,
    detail: (id: number) => ['camps', 'detail', id] as const,
    nearby: (lat: number, lng: number, radius: number) =>
      ['camps', 'nearby', { lat, lng, radius }] as const,
  },

  // Trainers
  trainers: {
    all: ['trainers'] as const,
    list: (filters?: TrainerFilters) => ['trainers', 'list', filters] as const,
    detail: (id: number) => ['trainers', 'detail', id] as const,
  },

  // Chat (for Phase 2)
  conversations: {
    all: ['conversations'] as const,
    detail: (id: string) => ['conversations', id] as const,
    messages: (conversationId: string) =>
      ['conversations', conversationId, 'messages'] as const,
  },
} as const;

// =============================================================================
// Filter Types
// =============================================================================

export interface CampFilters {
  state?: string;
  category?: 'summer' | 'winter-clinics' | string;
  search?: string;
  lat?: number;
  lng?: number;
  radius?: number;
}

export interface TrainerFilters {
  city?: string;
  specialty?: string;
  search?: string;
}

// =============================================================================
// Invalidation Helpers
// =============================================================================

/**
 * Invalidate all camp-related queries
 */
export const invalidateCamps = () => {
  queryClient.invalidateQueries({ queryKey: queryKeys.camps.all });
};

/**
 * Invalidate all trainer-related queries
 */
export const invalidateTrainers = () => {
  queryClient.invalidateQueries({ queryKey: queryKeys.trainers.all });
};

/**
 * Invalidate user data (profile + sessions)
 */
export const invalidateUser = () => {
  queryClient.invalidateQueries({ queryKey: queryKeys.user });
};

/**
 * Invalidate all queries (use sparingly - e.g., on login/logout)
 */
export const invalidateAll = () => {
  queryClient.invalidateQueries();
};

/**
 * Clear all cached data (use on logout)
 */
export const clearCache = () => {
  queryClient.clear();
};

export default queryClient;
