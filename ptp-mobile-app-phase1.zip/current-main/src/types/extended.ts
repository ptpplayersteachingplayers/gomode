/**
 * PTP Mobile App - Extended Types
 *
 * Additional types for Phase 1+ features:
 * - App configuration
 * - Enhanced camp data
 * - Chat/messaging types (Phase 2 prep)
 * - Home screen types
 */

import { Camp, Trainer, Session, User } from './index';

// =============================================================================
// App Configuration Types
// =============================================================================

/**
 * App configuration returned from /ptp/v1/app-config
 * Controls feature flags, promotions, and version gating
 */
export interface AppConfig {
  /** Feature flags */
  features: FeatureFlags;

  /** Currently active promotions/banners */
  promotions: PromoBanner[];

  /** Version gating for forced updates */
  versioning: VersionConfig;

  /** Available markets/states */
  markets: Market[];

  /** Contact/support info */
  support: SupportInfo;

  /** Last updated timestamp */
  updatedAt: string;
}

export interface FeatureFlags {
  /** Enable private training booking */
  enablePrivateTraining: boolean;

  /** Enable in-app messaging */
  enableMessaging: boolean;

  /** Enable camp waitlist */
  enableWaitlist: boolean;

  /** Enable push notifications */
  enablePushNotifications: boolean;

  /** Enable nearby camps feature */
  enableNearbyCamps: boolean;

  /** Enable trainer ratings/reviews */
  enableTrainerReviews: boolean;
}

export interface PromoBanner {
  id: string;
  title: string;
  body: string;
  ctaText?: string;
  ctaUrl?: string;
  imageUrl?: string;
  backgroundColor?: string;
  startDate?: string;
  endDate?: string;
  priority: number;
}

export interface VersionConfig {
  /** Minimum supported app version (force update below this) */
  minSupportedVersion: string;

  /** Latest available version */
  latestVersion: string;

  /** Update URL for app stores */
  updateUrl: {
    ios: string;
    android: string;
  };

  /** Optional message for update prompt */
  updateMessage?: string;
}

export interface Market {
  code: string;
  name: string;
  isActive: boolean;
}

export interface SupportInfo {
  email: string;
  phone?: string;
  hours?: string;
}

// =============================================================================
// Enhanced Camp Types
// =============================================================================

/**
 * Extended camp data with availability info
 */
export interface EnhancedCamp extends Camp {
  /** Total capacity */
  totalSeats: number;

  /** Available seats remaining */
  availableSeats: number;

  /** Whether waitlist is active */
  isWaitlistOnly: boolean;

  /** Age range (e.g., "6-14") */
  ageRange?: string;

  /** Skill level (e.g., "All Levels", "Advanced") */
  skillLevel?: string;

  /** List of trainers assigned to this camp */
  trainerIds?: number[];

  /** Distance from user (if nearby search) */
  distance?: number;

  /** Distance unit */
  distanceUnit?: 'miles' | 'km';

  /** Last updated timestamp */
  lastUpdatedAt: string;
}

/**
 * Camp availability status
 */
export type CampAvailability = 'available' | 'almost_full' | 'waitlist' | 'sold_out';

/**
 * Get availability status from camp data
 */
export function getCampAvailability(camp: EnhancedCamp): CampAvailability {
  if (camp.isWaitlistOnly) return 'waitlist';
  if (camp.availableSeats === 0) return 'sold_out';
  if (camp.availableSeats <= 5 || camp.almost_full) return 'almost_full';
  return 'available';
}

// =============================================================================
// Chat / Messaging Types (Phase 2 Preparation)
// =============================================================================

/**
 * Conversation type determines participants and context
 */
export type ConversationType = 'parent-trainer' | 'parent-support' | 'group';

/**
 * Conversation model
 */
export interface Conversation {
  id: string;
  type: ConversationType;

  /** Participant user IDs */
  participantIds: number[];

  /** Participant details (populated from WP users) */
  participants?: ConversationParticipant[];

  /** Optional linked camp ID */
  campId?: number;

  /** Optional linked session ID */
  sessionId?: number;

  /** Last message preview */
  lastMessage?: MessagePreview;

  /** Unread count for current user */
  unreadCount: number;

  /** Whether current user has muted this conversation */
  isMuted: boolean;

  createdAt: string;
  updatedAt: string;
}

export interface ConversationParticipant {
  id: number;
  name: string;
  avatar?: string;
  role: 'parent' | 'trainer' | 'support' | 'admin';
  isOnline?: boolean;
  lastSeenAt?: string;
}

export interface MessagePreview {
  text: string;
  senderId: number;
  createdAt: string;
}

/**
 * Message model
 */
export interface Message {
  id: string;
  conversationId: string;
  senderId: number;

  /** Message content */
  text: string;

  /** Optional attachments (future) */
  attachments?: MessageAttachment[];

  /** User IDs who have seen this message */
  seenBy: number[];

  /** System message flag (for automated messages) */
  isSystem: boolean;

  createdAt: string;
}

export interface MessageAttachment {
  id: string;
  type: 'image' | 'pdf' | 'link';
  url: string;
  name?: string;
  thumbnailUrl?: string;
}

/**
 * Send message payload
 */
export interface SendMessagePayload {
  conversationId: string;
  text: string;
  attachments?: Omit<MessageAttachment, 'id'>[];
}

// =============================================================================
// Home Screen / Dashboard Types
// =============================================================================

/**
 * Data needed for the concierge-style home screen
 */
export interface HomeScreenData {
  /** Current user */
  user: User;

  /** Next upcoming session */
  nextSession?: Session;

  /** Unread message count */
  unreadMessages: number;

  /** Active promotions */
  promotions: PromoBanner[];

  /** Quick stats */
  stats: {
    upcomingCamps: number;
    completedCamps: number;
  };
}

// =============================================================================
// API Response Types
// =============================================================================

/**
 * Paginated response wrapper
 */
export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    perPage: number;
    total: number;
    totalPages: number;
  };
}

/**
 * Nearby camps response
 */
export interface NearbyCampsResponse {
  camps: EnhancedCamp[];
  searchLocation: {
    lat: number;
    lng: number;
    radius: number;
    radiusUnit: 'miles' | 'km';
  };
}

// =============================================================================
// Request Types
// =============================================================================

/**
 * Nearby camps request params
 */
export interface NearbyCampsParams {
  lat: number;
  lng: number;
  radius?: number; // defaults to 50 miles
  category?: 'summer' | 'winter-clinics';
  limit?: number;
}

/**
 * Update user profile params
 */
export interface UpdateProfileParams {
  name?: string;
  phone?: string;
  zip?: string;
  preferredMarkets?: string[];
  notificationPreferences?: NotificationPreferences;
}

export interface NotificationPreferences {
  pushEnabled: boolean;
  emailEnabled: boolean;
  smsEnabled: boolean;
  marketingEnabled: boolean;
}

// =============================================================================
// Utility Types
// =============================================================================

/**
 * Common loading/error state
 */
export interface AsyncState<T> {
  data: T | undefined;
  isLoading: boolean;
  isRefreshing: boolean;
  error: Error | null;
}

/**
 * Timestamp type (ISO string)
 */
export type Timestamp = string;
