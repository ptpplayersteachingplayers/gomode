/**
 * PTP Mobile App - Authentication Context (Phase 1+)
 *
 * Provides:
 * - Current user state
 * - Loading state for auth operations
 * - Login/logout methods
 * - Automatic token loading on startup
 * - React Query cache management
 */

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from 'react';
import {
  login as apiLogin,
  getMe,
  setAuthToken,
  clearAuthToken,
  loadStoredToken,
  ApiClientError,
} from '../api/client';
import { clearCache, invalidateAll, queryClient } from '../api/queryClient';
import { User, LoginCredentials } from '../types';

// =============================================================================
// Types
// =============================================================================

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isInitialized: boolean;
  isGuest: boolean;
}

interface AuthContextValue extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => Promise<void>;
  continueAsGuest: () => void;
  /** Check if user is fully authenticated (not guest) */
  isAuthenticated: boolean;
}

// =============================================================================
// Context
// =============================================================================

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// =============================================================================
// Provider
// =============================================================================

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [state, setState] = useState<AuthState>({
    user: null,
    isLoading: false,
    isInitialized: false,
    isGuest: false,
  });

  /**
   * Initialize auth state by checking for stored token
   */
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const token = await loadStoredToken();

        if (token) {
          // Try to fetch user info with stored token
          try {
            const user = await getMe();
            setState({
              user,
              isLoading: false,
              isInitialized: true,
              isGuest: false,
            });

            // Prefetch common data after successful auth restore
            prefetchUserData();

          } catch (error) {
            // Token is invalid or expired, clear it
            console.log('Stored token invalid, clearing...');
            await clearAuthToken();
            // Also clear any cached data from the invalid session
            clearCache();
            setState({
              user: null,
              isLoading: false,
              isInitialized: true,
              isGuest: false,
            });
          }
        } else {
          // No stored token
          setState({
            user: null,
            isLoading: false,
            isInitialized: true,
            isGuest: false,
          });
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        setState({
          user: null,
          isLoading: false,
          isInitialized: true,
          isGuest: false,
        });
      }
    };

    initializeAuth();
  }, []);

  /**
   * Prefetch common data after login
   */
  const prefetchUserData = useCallback(async () => {
    try {
      // Import dynamically to avoid circular dependency
      const { getSessions, getCamps, getTrainers } = await import('../api/client');

      // Prefetch user sessions
      queryClient.prefetchQuery({
        queryKey: ['user', 'sessions'],
        queryFn: getSessions,
      });

      // Prefetch camps (public data, useful for home screen)
      queryClient.prefetchQuery({
        queryKey: ['camps', 'list', undefined],
        queryFn: getCamps,
      });

      // Prefetch trainers
      queryClient.prefetchQuery({
        queryKey: ['trainers', 'list', undefined],
        queryFn: getTrainers,
      });
    } catch (error) {
      console.log('Prefetch error (non-critical):', error);
    }
  }, []);

  /**
   * Login with credentials
   */
  const login = useCallback(async (credentials: LoginCredentials): Promise<void> => {
    setState((prev) => ({ ...prev, isLoading: true }));

    try {
      // Clear any existing cache from previous sessions
      clearCache();

      // Call login API
      const loginResponse = await apiLogin(credentials);

      // Store the token
      await setAuthToken(loginResponse.token);

      // Fetch full user info
      const user = await getMe();

      setState({
        user,
        isLoading: false,
        isInitialized: true,
        isGuest: false,
      });

      // Prefetch common data after successful login
      prefetchUserData();

    } catch (error) {
      setState((prev) => ({ ...prev, isLoading: false }));

      // Re-throw with user-friendly message
      if (error instanceof ApiClientError) {
        // Handle specific login errors
        if (error.code === 'invalid_username' || error.code === 'incorrect_password') {
          throw new Error('Invalid email or password. Please try again.');
        }
        if (error.code === '[jwt_auth] invalid_username') {
          throw new Error('Invalid email or password. Please try again.');
        }
        if (error.code === '[jwt_auth] incorrect_password') {
          throw new Error('Invalid email or password. Please try again.');
        }
        throw new Error(error.message);
      }

      throw new Error('Unable to log in. Please check your connection and try again.');
    }
  }, [prefetchUserData]);

  /**
   * Logout - clear token, user, and React Query cache
   */
  const logout = useCallback(async (): Promise<void> => {
    try {
      await clearAuthToken();
    } catch (error) {
      console.error('Error clearing token:', error);
    }

    // Clear all React Query cache to remove user-specific data
    clearCache();

    setState({
      user: null,
      isLoading: false,
      isInitialized: true,
      isGuest: false,
    });
  }, []);

  /**
   * Continue as guest - allow browsing without login
   */
  const continueAsGuest = useCallback((): void => {
    // Clear any previous user's cache
    clearCache();

    setState({
      user: null,
      isLoading: false,
      isInitialized: true,
      isGuest: true,
    });
  }, []);

  const value: AuthContextValue = {
    ...state,
    login,
    logout,
    continueAsGuest,
    isAuthenticated: state.user !== null && !state.isGuest,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// =============================================================================
// Hook
// =============================================================================

export const useAuth = (): AuthContextValue => {
  const context = useContext(AuthContext);

  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
};

// =============================================================================
// Export
// =============================================================================

export default AuthContext;
