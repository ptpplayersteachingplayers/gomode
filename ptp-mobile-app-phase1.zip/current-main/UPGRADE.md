# PTP Mobile App - Phase 1 Upgrade Guide

This document covers the Phase 1 implementation of the dynamic data layer and enhanced WordPress API. It also provides roadmap guidance for Phases 2-4.

## What's New in Phase 1

### 1. React Query Integration

React Query replaces the custom `useApi` hook with powerful features:

- **Automatic caching** - Data persists across screen navigations
- **Background refresh** - Stale data shown immediately while fetching fresh data
- **Retry logic** - Automatic retry on network failures
- **Refetch on focus** - Data refreshes when app comes to foreground
- **Query invalidation** - Easy cache management

#### Installation

```bash
npm install @tanstack/react-query @react-native-community/netinfo expo-application
```

#### New Files

| File | Purpose |
|------|---------|
| `src/api/queryClient.ts` | Query client config, stale times, query keys |
| `src/api/QueryProvider.tsx` | Provider component with mobile focus handling |
| `src/hooks/useCampsQuery.ts` | React Query hooks for camps |
| `src/hooks/useTrainersQuery.ts` | React Query hooks for trainers |
| `src/hooks/useSessionsQuery.ts` | React Query hooks for sessions/user |
| `src/hooks/useAppConfig.ts` | App config, feature flags, promotions |

### 2. Enhanced WordPress Plugin

The new `ptp-mobile-api-v2.php` plugin adds:

#### New Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /ptp/v1/app-config` | Feature flags, promotions, version info |
| `GET /ptp/v1/home` | Combined home screen data (reduces API calls) |
| `GET /ptp/v1/camps?lat=&lng=&radius=` | Geo-filtered camps search |

#### Enhanced Endpoints

- **`/camps`** now returns `totalSeats`, `availableSeats`, `isWaitlistOnly`, `lastUpdatedAt`
- **`/me`** now includes `phone` and `zip`

#### Admin Features

- Settings page for feature flags and version gating
- Promotions management UI
- Support info configuration

### 3. New Types

Extended types in `src/types/extended.ts`:

- `AppConfig`, `FeatureFlags`, `PromoBanner`
- `EnhancedCamp` with availability info
- `Conversation`, `Message` (Phase 2 prep)
- `HomeScreenData`

### 4. New Screens

- `HomeScreen.tsx` - Concierge-style dashboard
- `CampsScreenV2.tsx` - Refactored with React Query

---

## Migration Guide

### Step 1: Install Dependencies

```bash
cd /path/to/ptp-mobile-app
npm install @tanstack/react-query @react-native-community/netinfo expo-application
```

### Step 2: Update App.tsx

Wrap your app with `QueryProvider`:

```tsx
import { QueryProvider } from './src/api/QueryProvider';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <QueryProvider>
        <AuthProvider>
          <AppNavigator />
        </AuthProvider>
      </QueryProvider>
    </SafeAreaProvider>
  );
}
```

### Step 3: Install WordPress Plugin

1. Upload `ptp-mobile-api-v2.php` to your WordPress plugins folder
2. Deactivate the old `ptp-mobile-api` plugin
3. Activate the new `ptp-mobile-api-v2` plugin
4. Go to **PTP Mobile App** in the admin menu to configure settings

### Step 4: Migrate Screens to React Query

Replace custom hooks with React Query hooks:

```tsx
// Before
import { useCamps } from '../hooks';
const { camps, isLoading, error, refresh } = useCamps();

// After
import { useCampsQuery } from '../hooks';
const { camps, isLoading, error, refetch, isStale, dataUpdatedAt } = useCampsQuery();
```

Key differences:
- `refresh()` → `refetch()` (same functionality)
- New: `isStale` boolean for showing update indicators
- New: `dataUpdatedAt` timestamp for "Updated X mins ago"

### Step 5: Add Home Screen to Navigation

Update your navigation to include the HomeScreen as the default landing:

```tsx
// In navigation/index.tsx
<Tab.Screen
  name="HomeTab"
  component={HomeScreen}
  options={{
    tabBarLabel: 'Home',
    tabBarIcon: ({ color }) => <Icon name="home" color={color} />,
  }}
/>
```

---

## Configuration Reference

### Stale Times (in queryClient.ts)

| Data Type | Stale Time | Rationale |
|-----------|------------|-----------|
| App Config | 30 minutes | Changes rarely |
| Camps | 5 minutes | Occasional updates |
| Trainers | 10 minutes | Changes rarely |
| Sessions | 1 minute | User-specific, needs freshness |
| User | 5 minutes | Profile data |
| Messages | 0 | Real-time (Phase 2) |

### Feature Flags

Feature flags are managed in WordPress Admin → PTP Mobile App:

| Flag | Default | Description |
|------|---------|-------------|
| `enablePrivateTraining` | true | Show private training booking |
| `enableMessaging` | false | Enable in-app chat (Phase 2) |
| `enableWaitlist` | true | Allow camp waitlist signups |
| `enablePushNotifications` | true | Push notification features |
| `enableNearbyCamps` | true | Location-based search |
| `enableTrainerReviews` | false | Trainer ratings system |

---

## Phase 2: Real-time Messaging (Next Steps)

### Backend Setup

Choose one:
- **Supabase** (recommended) - Postgres + Realtime + Row Level Security
- **Firebase** - Firestore + FCM
- **Pusher/Ably** - Pure messaging layer

### Implementation Checklist

1. [ ] Set up Supabase project
2. [ ] Create tables: `users`, `conversations`, `messages`
3. [ ] Add sync function in WordPress (webhook on user create/order)
4. [ ] Create `ChatListScreen.tsx` and `ChatScreen.tsx`
5. [ ] Add real-time subscriptions with `supabase.channel()`
6. [ ] Implement push notifications for new messages

### Data Model

```sql
-- Conversations
CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL, -- 'parent-trainer', 'parent-support', 'group'
  participant_ids INTEGER[] NOT NULL,
  camp_id INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Messages
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES conversations(id),
  sender_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  seen_by INTEGER[] DEFAULT '{}',
  is_system BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

## Phase 3: PTP Support Console

A simple React web app for your VA to manage conversations:

### Features
- List of open conversations (filtered by unread, priority)
- Message view with send functionality
- Quick context from WordPress (orders, kids, camps)
- Assignment and tagging system

### Tech Stack
- React + Vite
- Same Supabase backend as mobile
- Tailwind CSS for styling
- Deployed on Vercel or your WordPress host

---

## Phase 4: Polish & UX

### Home Screen Enhancements
- [ ] Add child photo/initials to session cards
- [ ] "Add to Calendar" deep link
- [ ] Weather alerts for outdoor sessions
- [ ] Trainer quick-message button

### Real-time Signals
- [ ] Seat availability live updates
- [ ] Camp status change notifications
- [ ] Weather/location change alerts via system messages

### Push Notification Flows
- [ ] New message → push with preview
- [ ] Booking confirmation → push with "Add to Calendar?"
- [ ] Session reminder → 24h and 2h before
- [ ] Camp almost full → for waitlist users

---

## File Structure After Phase 1

```
src/
├── api/
│   ├── client.ts              # Axios client (unchanged)
│   ├── queryClient.ts         # NEW: React Query config
│   └── QueryProvider.tsx      # NEW: Provider component
├── hooks/
│   ├── useApi.ts              # Legacy (still works)
│   ├── useCamps.ts            # Legacy (still works)
│   ├── useCampsQuery.ts       # NEW: React Query version
│   ├── useTrainersQuery.ts    # NEW: React Query version
│   ├── useSessionsQuery.ts    # NEW: React Query version
│   ├── useAppConfig.ts        # NEW: Feature flags
│   └── index.ts               # Updated exports
├── screens/
│   ├── CampsScreen.tsx        # Original (still works)
│   ├── CampsScreenV2.tsx      # NEW: React Query version
│   ├── HomeScreen.tsx         # NEW: Dashboard
│   └── ...
├── types/
│   ├── index.ts               # Core types
│   └── extended.ts            # NEW: Phase 1+ types
└── ...

wordpress-plugin/
├── ptp-mobile-api/            # Original plugin
│   └── ptp-mobile-api.php
└── ptp-mobile-api-v2/         # NEW: Enhanced plugin
    └── ptp-mobile-api-v2.php
```

---

## Testing Checklist

### React Query
- [ ] Camps load and cache correctly
- [ ] Pull-to-refresh triggers refetch
- [ ] Stale indicator shows after 5 minutes
- [ ] Data persists across screen navigation
- [ ] Session expiry logs out user

### WordPress API
- [ ] `/app-config` returns feature flags
- [ ] `/camps` includes `availableSeats` and `totalSeats`
- [ ] `/home` returns combined data
- [ ] Geo-filtering works with lat/lng params
- [ ] Admin settings save correctly

### Home Screen
- [ ] Greeting shows user's first name
- [ ] Next session displays correctly
- [ ] Quick actions navigate properly
- [ ] Promotions display and link works
- [ ] Stats show correct counts

---

## Support

For questions about this implementation, contact your development team or refer to:
- [React Query Documentation](https://tanstack.com/query/latest)
- [Supabase Documentation](https://supabase.com/docs)
- [Expo Documentation](https://docs.expo.dev)
